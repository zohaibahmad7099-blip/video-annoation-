"""Dataset video registry keyed by content hash (labels/videos.json).

Identity is the SHA-256 of the file: the same video copied to two places is one
entry, and a held-out video stays held out wherever a copy appears. The
video_key is the stem of the first path seen, so it matches the video name.
"""
import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List

import cv2

VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv"}


@dataclass
class VideoEntry:
    video_key: str
    sha256: str
    name: str                      # stem of the first path seen; used for output file names
    paths: List[str] = field(default_factory=list)
    width: int = 0
    height: int = 0
    nominal_fps: float = 0.0
    frame_count: int = 0
    session_id: str = ""           # recording session (same day/actors) - required for splits
    staged: bool = True            # acted for the dataset vs real store footage
    holdout: bool = False          # never used for training or model selection
    notes: str = ""


def sha256_of(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while block := f.read(chunk):
            h.update(block)
    return h.hexdigest()


def load_registry(path: Path) -> Dict[str, VideoEntry]:
    path = Path(path)
    if not path.is_file():
        return {}
    registry = {}
    for data in json.loads(path.read_text(encoding="utf-8")).values():
        entry = VideoEntry(**data)
        entry.video_key = entry.name
        if entry.name in registry and registry[entry.name].sha256 != entry.sha256:
            raise ValueError(f"video name '{entry.name}' is used by different video content")
        registry[entry.name] = entry
    return registry


def save_registry(path: Path, reg: Dict[str, VideoEntry]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({k: asdict(v) for k, v in sorted(reg.items(), key=lambda kv: kv[1].name)},
                               indent=1), encoding="utf-8")


def register_video(path: Path, reg: Dict[str, VideoEntry]) -> VideoEntry:
    """Register one video, or return the existing entry for identical content."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Video file not found: {path}")
    digest = sha256_of(path)
    absolute_path = str(path.resolve())
    duplicate = next((e for e in reg.values() if e.sha256 == digest), None)
    if duplicate is not None:
        if absolute_path not in duplicate.paths:
            duplicate.paths.append(absolute_path)
        return duplicate

    name = path.stem
    if name in reg:
        raise ValueError(f"video name '{name}' is already registered with different content")
    cap = cv2.VideoCapture(absolute_path, cv2.CAP_FFMPEG)
    if not cap.isOpened():
        cap.release()
        raise IOError(f"Cannot open video: {path}")
    entry = VideoEntry(name, digest, name, [absolute_path],
                       int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                       int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
                       round(float(cap.get(cv2.CAP_PROP_FPS) or 0), 3),
                       int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0))
    cap.release()
    reg[name] = entry
    return entry


def scan(root: Path, reg: Dict[str, VideoEntry]) -> List[str]:
    """Add every video under root; returns human-readable change lines. Existing
    metadata (session, holdout, staged, notes) is never overwritten."""
    changes = []
    for p in sorted(Path(root).rglob("*")):
        if p.suffix.lower() not in VIDEO_EXT or not p.is_file():
            continue
        digest = sha256_of(p)
        ap = str(p.resolve())
        duplicate = next((e for e in reg.values() if e.sha256 == digest), None)
        if duplicate is not None:
            if ap not in duplicate.paths:
                duplicate.paths.append(ap)
                changes.append(f"duplicate copy of '{duplicate.name}' ({duplicate.video_key}) at {ap}")
            continue
        key = p.stem
        if key in reg:
            raise ValueError(f"video name '{key}' is used by different video content "
                             f"({reg[key].sha256}, {digest})")
        cap = cv2.VideoCapture(ap, cv2.CAP_FFMPEG)
        e = VideoEntry(key, digest, p.stem, [ap], int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                       int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)), round(float(cap.get(cv2.CAP_PROP_FPS) or 0), 3),
                       int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0))
        cap.release()
        reg[key] = e
        changes.append(f"new '{p.stem}' ({key}) {e.width}x{e.height}")
    names = {}
    for e in reg.values():
        if e.name in names:
            changes.append(f"WARNING: two different videos share the name '{e.name}' "
                           f"({names[e.name]}, {e.video_key}); output files would collide")
        names[e.name] = e.video_key
    return changes


def find(reg: Dict[str, VideoEntry], ref: str) -> VideoEntry:
    """Look up by video_key, name (stem) or any path."""
    ref_l = ref.lower()
    for e in reg.values():
        if ref_l in (e.video_key, e.name.lower()) or any(Path(p).name.lower() == ref_l or p.lower() == ref_l for p in e.paths):
            return e
    raise KeyError(f"No registered video matches {ref!r}")
