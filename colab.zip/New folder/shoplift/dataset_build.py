"""Build Stage A training data from labels/ x one or more extractions.

  python -m shoplift.dataset_build --source yolo11m_10hz --source yolo26m_10hz --out datasets/stage_a_v1

For every registered, labelled video and every extraction source, each tracks
row is matched to a labelled person by time and box IoU (>= 0.5). Contiguous
runs of rows matched to one person become a sequence; a tracker ID switch
therefore splits a track instead of mixing people. Stored per sequence: raw
COCO-17 keypoints in source pixels (x, y, conf), boxes, detection confidence,
timestamps, and the derived targets (shoplift.annotation.targets). Features are
computed by the model code, so the input contract can change without relabelling.

Splits: videos are grouped by session_id; sessions sharing an actor_id are merged
(union-find), so no person appears on both sides. Holdout videos are split
"holdout" and never assigned to a fold.
"""
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from shoplift.annotation import PHASES, VISIBILITY, Person, lint, load, targets
from shoplift.registry import load_registry

ROOT = Path(__file__).resolve().parent.parent
COCO17 = ["nose", "left_eye", "right_eye", "left_ear", "right_ear", "left_shoulder", "right_shoulder",
          "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip",
          "left_knee", "right_knee", "left_ankle", "right_ankle"]


def _iou(a: np.ndarray, b: np.ndarray) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter + 1e-9)


class PersonIndex:
    """Nearest-time box lookup for the labelled persons of one video."""

    def __init__(self, persons: List[Person], max_dt: float = 0.06):
        self.persons = [p for p in persons if p.boxes]
        self.t = [np.array([b[0] for b in p.boxes]) for p in self.persons]
        self.b = [np.array([b[1:] for b in p.boxes]) for p in self.persons]
        self.max_dt = max_dt

    def match(self, t: float, box: np.ndarray, min_iou: float = 0.5) -> Optional[Person]:
        best, best_iou = None, min_iou
        for p, ts, bs in zip(self.persons, self.t, self.b):
            i = int(np.searchsorted(ts, t))
            for j in (i - 1, i):
                if 0 <= j < len(ts) and abs(ts[j] - t) <= self.max_dt:
                    v = _iou(bs[j], box)
                    if v >= best_iou:
                        best, best_iou = p, v
        return best


def _groups(entries, persons_by_video: Dict[str, List[Person]]) -> Dict[str, str]:
    """video_key -> group id (sessions merged through shared actor ids)."""
    parent = {}

    def root(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        parent[root(a)] = root(b)

    for e in entries:
        s = f"session:{e.session_id or 'video:' + e.video_key}"
        root(s)
        for p in persons_by_video.get(e.video_key, []):
            if p.actor_id:
                union(s, f"actor:{p.actor_id}")
    return {e.video_key: root(f"session:{e.session_id or 'video:' + e.video_key}") for e in entries}


def build(sources: List[str], out: Path, extract_root: Path, folds: int = 5, allow_missing_session: bool = False,
          include_incomplete: bool = False, labels_dir: Path = ROOT / "labels") -> Dict:
    reg = load_registry(labels_dir / "videos.json")
    out.mkdir(parents=True, exist_ok=True)
    problems, labelled, persons_by_video = [], [], {}
    for e in reg.values():
        lp = labels_dir / f"{e.video_key}.json"
        if not lp.is_file():
            continue
        L = load(lp)
        errs, _ = lint(L)
        if errs:
            problems.append(f"{e.name}: {len(errs)} label errors - skipped (run annotate.py / lint)")
            continue
        if not L.complete and not include_incomplete:
            problems.append(f"{e.name}: labels not marked complete - skipped")
            continue
        if not e.session_id and not e.holdout:
            if not allow_missing_session:
                raise SystemExit(f"{e.name}: session_id missing in labels/videos.json "
                                 f"(register_videos.py --session). Splits would leak.")
            problems.append(f"{e.name}: no session_id - grouped alone (may leak actors across folds)")
        labelled.append((e, L))
        persons_by_video[e.video_key] = L.persons
    groups = _groups([e for e, _ in labelled if not e.holdout], persons_by_video)
    names = sorted(set(groups.values()), key=lambda g: hashlib.sha1(g.encode()).hexdigest())
    fold_of = {g: i % max(1, folds) for i, g in enumerate(names)}

    manifest, coverage = [], defaultdict(lambda: [0.0, 0.0])
    for e, L in labelled:
        index = PersonIndex(L.persons)
        for src in sources:
            tracks = extract_root / src / f"{e.name}_tracks.csv"
            summ = extract_root / src / f"{e.name}_summary.json"
            if not tracks.is_file():
                problems.append(f"{e.name}: no {src} extraction")
                continue
            sm = json.loads(summ.read_text(encoding="utf-8")) if summ.is_file() else {}
            if sm.get("video", {}).get("sha256") not in (None, e.sha256):
                problems.append(f"{e.name}/{src}: extraction is of a different file (hash mismatch) - skipped")
                continue
            df = pd.read_csv(tracks).sort_values(["track_id", "timestamp_s"])
            for tid, g in df.groupby("track_id"):
                rows = g.reset_index(drop=True)
                who = [index.match(r.timestamp_s, np.array([r.x1, r.y1, r.x2, r.y2])) for r in rows.itertuples()]
                run_start = 0
                for i in range(1, len(rows) + 1):
                    if i < len(rows) and who[i] is who[run_start]:
                        continue
                    p = who[run_start]
                    seg = rows.iloc[run_start:i]
                    run_start = i
                    if p is None or len(seg) < 2:
                        continue
                    t = seg.timestamp_s.to_numpy(float)
                    tg = targets(p, t)
                    kp = np.stack([seg[[f"{k}_x", f"{k}_y", f"{k}_c"]].to_numpy(np.float32) for k in COCO17], axis=1)
                    seq_id = f"{e.video_key}-{src}-t{tid}-{p.person_id}-{t[0]:.1f}"
                    rel = Path(src) / e.video_key / f"{seq_id}.npz"
                    (out / rel).parent.mkdir(parents=True, exist_ok=True)
                    np.savez_compressed(out / rel, times=t, keypoints=kp,
                                        boxes=seg[["x1", "y1", "x2", "y2"]].to_numpy(np.float32),
                                        det_conf=seg.conf.to_numpy(np.float32),
                                        suspicious=tg.suspicious, suspicious_mask=tg.suspicious_mask,
                                        visibility=tg.visibility, phase=tg.phase,
                                        event_id=tg.event_id.astype(str))
                    coverage[(e.name, src)][0] += len(seg) / 10.0
                    manifest.append({
                        "seq_id": seq_id, "path": str(rel).replace("\\", "/"), "video_key": e.video_key,
                        "video": e.name, "source": src, "pose_weights_sha256": sm.get("pose_weights_sha256"),
                        "person_id": p.person_id, "actor_id": p.actor_id, "is_staff": p.is_staff,
                        "session_id": e.session_id, "group": groups.get(e.video_key, "holdout"),
                        "split": "holdout" if e.holdout else f"fold{fold_of[groups[e.video_key]]}",
                        "complete_video": L.complete, "steps": int(len(t)),
                        "positive_steps": int((tg.suspicious * tg.suspicious_mask).sum()),
                        "trainable_steps": int(tg.suspicious_mask.sum()),
                        "events": sorted({x for x in tg.event_id if x})})
            for p in L.persons:
                coverage[(e.name, src)][1] += (p.span[1] - p.span[0]) if p.span else 0.0
    (out / "manifest.jsonl").write_text("\n".join(json.dumps(m) for m in manifest) + "\n", encoding="utf-8")
    report = {
        "sources": sources, "videos": len(labelled), "sequences": len(manifest), "problems": problems,
        "phases": PHASES, "visibility": VISIBILITY,
        "by_split": {s: {"sequences": sum(m["split"] == s for m in manifest),
                         "positive_steps": sum(m["positive_steps"] for m in manifest if m["split"] == s),
                         "events": len({(m["video_key"], ev) for m in manifest if m["split"] == s for ev in m["events"]})}
                     for s in sorted({m["split"] for m in manifest})},
        "label_coverage_by_extraction": {f"{v}|{s}": round(a / b, 2) if b else None for (v, s), (a, b) in coverage.items()},
    }
    (out / "build_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", action="append", required=True, help="Extraction folder under --extract-root")
    ap.add_argument("--extract-root", type=Path, default=ROOT / "outputs" / "extract")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--allow-missing-session", action="store_true")
    ap.add_argument("--include-incomplete", action="store_true")
    a = ap.parse_args()
    r = build(a.source, a.out, a.extract_root, a.folds, a.allow_missing_session, a.include_incomplete)
    print(json.dumps({k: v for k, v in r.items() if k not in ("phases", "visibility")}, indent=2))


if __name__ == "__main__":
    main()
