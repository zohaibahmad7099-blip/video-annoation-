"""ByteTrack on merged (tiled) detections, with all low-confidence boxes passed in.

The legacy loop filtered at conf=0.35 before the tracker, so ByteTrack's
second association stage (0.1-0.5) never saw partially occluded shoppers.
"""
from types import SimpleNamespace
from typing import Dict, List

import numpy as np

from shoplift.tiling import Detections


class _UltralyticsBoxes:
    """Minimal stand-in for ultralytics Boxes: what BYTETracker.update reads."""

    def __init__(self, xyxy: np.ndarray, conf: np.ndarray):
        self.xyxy = xyxy.astype(np.float32)
        self.conf = conf.astype(np.float32)
        self.cls = np.zeros(len(conf), np.float32)
        wh = self.xyxy[:, 2:] - self.xyxy[:, :2]
        self.xywh = np.concatenate([self.xyxy[:, :2] + wh / 2, wh], axis=1)

    def __len__(self):
        return len(self.conf)

    def __getitem__(self, idx):
        sub = _UltralyticsBoxes(self.xyxy[idx], self.conf[idx])
        return sub


class PersonTracker:
    def __init__(self, analysis_hz: float, buffer_s: float = 3.0, high: float = 0.5, low: float = 0.1,
                 new_track: float = 0.6, match: float = 0.8):
        from ultralytics.trackers.byte_tracker import BYTETracker
        args = SimpleNamespace(
            tracker_type="bytetrack", track_high_thresh=high, track_low_thresh=low,
            new_track_thresh=new_track, track_buffer=max(1, int(round(buffer_s * analysis_hz))),
            match_thresh=match, fuse_score=True)
        # Track buffer must count analysed frames. Ultralytics >= 8.4 uses it directly;
        # older versions scale it by frame_rate/30, so frame_rate=30 is neutral there.
        try:
            self.tracker = BYTETracker(args, frame_rate=30)
        except TypeError:
            self.tracker = BYTETracker(args)

    def reset(self):
        self.tracker.reset()

    def update(self, det: Detections) -> List[Dict]:
        if not len(det):
            self.tracker.update(_UltralyticsBoxes(np.zeros((0, 4)), np.zeros(0)))
            return []
        out = self.tracker.update(_UltralyticsBoxes(det.xyxy, det.conf))
        tracks = []
        for row in np.asarray(out):
            # [x1, y1, x2, y2, track_id, score, cls, det_index]
            i = int(row[-1])
            tracks.append({"track_id": int(row[4]), "bbox": det.xyxy[i].copy(),
                           "conf": float(det.conf[i]), "keypoints": det.keypoints[i].copy()})
        return tracks
