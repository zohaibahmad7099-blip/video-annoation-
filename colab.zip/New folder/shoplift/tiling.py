"""Tile a wide panorama so people keep enough pixels in the network input.

A 5120x1520 frame letterboxed to 640 shrinks people 8x. Three overlapping
1920-wide tiles at imgsz 1280 keep a 0.67 scale, run as one batch.
"""
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np


@dataclass
class Tile:
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def w(self):
        return self.x2 - self.x1

    @property
    def h(self):
        return self.y2 - self.y1


@dataclass
class Detections:
    xyxy: np.ndarray       # (N, 4) full-frame pixels
    conf: np.ndarray       # (N,)
    keypoints: np.ndarray  # (N, 17, 3) x, y, conf in full-frame pixels

    def __len__(self):
        return len(self.conf)

    def subset(self, mask) -> "Detections":
        return Detections(self.xyxy[mask], self.conf[mask], self.keypoints[mask])

    @staticmethod
    def empty() -> "Detections":
        return Detections(np.zeros((0, 4), np.float32), np.zeros(0, np.float32), np.zeros((0, 17, 3), np.float32))


def _spans(start: int, end: int, size: int, overlap: int, stretch: float = 1.15) -> List[Tuple[int, int]]:
    length = end - start
    # Slightly oversize regions get one stretched tile (small scale loss) rather
    # than two near-identical tiles that double the inference cost.
    if length <= size * stretch:
        return [(start, end)]
    n = int(np.ceil((length - overlap) / (size - overlap)))
    step = (length - size) / (n - 1)
    return [(start + int(round(i * step)), start + int(round(i * step)) + size) for i in range(n)]


def make_tiles(width: int, height: int, tile_w: int, tile_h: int, overlap: int,
               regions: Optional[Sequence[Tuple[int, int, int, int]]] = None, margin: int = 64) -> List[Tile]:
    """Cover the full frame, or only the given region bounds (expanded by margin)."""
    if overlap >= min(tile_w, tile_h):
        raise ValueError("overlap must be smaller than the tile size")
    boxes = regions or [(0, 0, width, height)]
    tiles: List[Tile] = []
    for x1, y1, x2, y2 in boxes:
        x1, y1 = max(0, x1 - margin), max(0, y1 - margin)
        x2, y2 = min(width, x2 + margin), min(height, y2 + margin)
        for ty1, ty2 in _spans(y1, y2, min(tile_h, y2 - y1), overlap):
            for tx1, tx2 in _spans(x1, x2, min(tile_w, x2 - x1), overlap):
                t = Tile(tx1, ty1, tx2, ty2)
                if not any(t.x1 >= o.x1 and t.y1 >= o.y1 and t.x2 <= o.x2 and t.y2 <= o.y2 for o in tiles):
                    tiles.append(t)
    return tiles


def _iou(box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    ix1 = np.maximum(box[0], boxes[:, 0])
    iy1 = np.maximum(box[1], boxes[:, 1])
    ix2 = np.minimum(box[2], boxes[:, 2])
    iy2 = np.minimum(box[3], boxes[:, 3])
    inter = np.clip(ix2 - ix1, 0, None) * np.clip(iy2 - iy1, 0, None)
    area = lambda b: (b[..., 2] - b[..., 0]) * (b[..., 3] - b[..., 1])
    return inter / (area(box) + area(boxes) - inter + 1e-9)


def _ios(box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    """Intersection over the smaller box: catches a truncated duplicate inside a full box."""
    ix1 = np.maximum(box[0], boxes[:, 0])
    iy1 = np.maximum(box[1], boxes[:, 1])
    ix2 = np.minimum(box[2], boxes[:, 2])
    iy2 = np.minimum(box[3], boxes[:, 3])
    inter = np.clip(ix2 - ix1, 0, None) * np.clip(iy2 - iy1, 0, None)
    area = lambda b: (b[..., 2] - b[..., 0]) * (b[..., 3] - b[..., 1])
    return inter / (np.minimum(area(box), area(boxes)) + 1e-9)


def _seen_whole_elsewhere(b: np.ndarray, sides: Tuple[bool, bool, bool, bool], t: Tile,
                          tiles: List[Tile], extra: int) -> bool:
    """True if another tile extends past every cut side of box b and contains it otherwise.

    Zone tiles have outer edges that border no other tile; a person cut there must
    be kept (truncated) rather than dropped.
    """
    left, right, top, bottom = sides
    for o in tiles:
        if o is t:
            continue
        if left and not o.x1 <= t.x1 - extra:
            continue
        if right and not o.x2 >= t.x2 + extra:
            continue
        if top and not o.y1 <= t.y1 - extra:
            continue
        if bottom and not o.y2 >= t.y2 + extra:
            continue
        if ((left or o.x1 <= b[0]) and (right or o.x2 >= b[2])
                and (top or o.y1 <= b[1]) and (bottom or o.y2 >= b[3])):
            return True
    return False


def merge(per_tile: List[Detections], tiles: List[Tile], width: int, height: int,
          iou_thresh: float = 0.5, ios_thresh: float = 0.8, edge_px: int = 4, extra_px: int = 64) -> Detections:
    """Drop boxes cut by a tile edge that another tile sees past, then suppress duplicates."""
    kept = []
    for det, t in zip(per_tile, tiles):
        if not len(det):
            continue
        b = det.xyxy
        sides = np.stack([(b[:, 0] <= t.x1 + edge_px) & (t.x1 > 0),
                          (b[:, 2] >= t.x2 - edge_px) & (t.x2 < width),
                          (b[:, 1] <= t.y1 + edge_px) & (t.y1 > 0),
                          (b[:, 3] >= t.y2 - edge_px) & (t.y2 < height)], axis=1)
        drop = np.array([s.any() and _seen_whole_elsewhere(box, tuple(s), t, tiles, extra_px)
                         for box, s in zip(b, sides)], bool)
        kept.append(det.subset(~drop))
    if not kept:
        return Detections.empty()
    all_d = Detections(np.concatenate([d.xyxy for d in kept]), np.concatenate([d.conf for d in kept]),
                       np.concatenate([d.keypoints for d in kept]))
    order = np.argsort(-all_d.conf)
    keep: List[int] = []
    while len(order):
        i = order[0]
        keep.append(i)
        rest = order[1:]
        if not len(rest):
            break
        dup = (_iou(all_d.xyxy[i], all_d.xyxy[rest]) > iou_thresh) | (_ios(all_d.xyxy[i], all_d.xyxy[rest]) > ios_thresh)
        order = rest[~dup]
    return all_d.subset(np.array(keep, int))


def fuse_scales(fine: Detections, coarse: Detections, iou_thresh: float = 0.4, ios_thresh: float = 0.7) -> Detections:
    """Fuse fine-tile and coarse full-frame detections of the same people.

    The COCO pose model is not monotonic in scale on this overhead camera: a
    back-facing shopper scored ~0.9 at full-frame 640 but 0.01-0.5 in a 1280
    tile. A matched pair keeps the fine box (better localisation), the higher
    confidence, and per joint the estimate with the higher keypoint confidence.
    Unmatched detections from either scale are kept.
    """
    if not len(coarse):
        return fine
    if not len(fine):
        return coarse
    xyxy, conf, kp = fine.xyxy.copy(), fine.conf.copy(), fine.keypoints.copy()
    taken = np.zeros(len(fine), bool)
    extra = []
    for j in np.argsort(-coarse.conf):
        cb = coarse.xyxy[j]
        overlap = np.maximum(_iou(cb, xyxy), (_ios(cb, xyxy) > ios_thresh) * iou_thresh)
        overlap[taken] = 0
        i = int(np.argmax(overlap))
        if overlap[i] < iou_thresh:
            extra.append(j)
            continue
        taken[i] = True
        conf[i] = max(conf[i], coarse.conf[j])
        better = coarse.keypoints[j, :, 2] > kp[i, :, 2]
        kp[i, better] = coarse.keypoints[j, better]
    if extra:
        e = np.array(extra, int)
        xyxy = np.concatenate([xyxy, coarse.xyxy[e]])
        conf = np.concatenate([conf, coarse.conf[e]])
        kp = np.concatenate([kp, coarse.keypoints[e]])
    return Detections(xyxy, conf, kp)


def _to_detections(r, off_x: float = 0.0, off_y: float = 0.0) -> Detections:
    if r.boxes is None or not len(r.boxes):
        return Detections.empty()
    off = np.array([off_x, off_y], np.float32)
    xyxy = r.boxes.xyxy.cpu().numpy().astype(np.float32) + np.tile(off, 2)
    conf = r.boxes.conf.cpu().numpy().astype(np.float32)
    if r.keypoints is not None and r.keypoints.data is not None and r.keypoints.data.shape[1] == 17:
        kp = r.keypoints.data.cpu().numpy().astype(np.float32).copy()
        missing = (kp[..., 0] == 0) & (kp[..., 1] == 0)  # YOLO pads missing joints with 0,0
        kp[..., :2] += off
        kp[missing] = 0
    else:
        kp = np.zeros((len(conf), 17, 3), np.float32)
    return Detections(xyxy, conf, kp)


class TiledPose:
    """Batched Ultralytics pose inference over tiles, optionally fused with a
    coarse full-frame pass. FP32 only (Pascal FP16 is 1/64 rate)."""

    def __init__(self, weights: str, imgsz: int = 1280, conf: float = 0.1, iou: float = 0.6,
                 device: str = "0", tile_w: int = 1920, tile_h: int = 1520, overlap: int = 256,
                 coarse_imgsz: int = 640):
        from ultralytics import YOLO
        self.model = YOLO(weights)
        self.imgsz, self.conf, self.iou, self.device = imgsz, conf, iou, device
        self.tile_w, self.tile_h, self.overlap = tile_w, tile_h, overlap
        self.coarse_imgsz = coarse_imgsz
        self._tiles_key = None
        self.tiles: List[Tile] = []

    def plan(self, width: int, height: int, regions=None) -> List[Tile]:
        key = (width, height, tuple(regions or ()))
        if key != self._tiles_key:
            self.tiles = make_tiles(width, height, self.tile_w, self.tile_h, self.overlap, regions)
            self._tiles_key = key
        return self.tiles

    def __call__(self, image: np.ndarray, regions=None) -> Detections:
        h, w = image.shape[:2]
        tiles = self.plan(w, h, regions)
        crops = [image[t.y1:t.y2, t.x1:t.x2] for t in tiles]
        results = self.model.predict(crops, imgsz=self.imgsz, conf=self.conf, iou=self.iou, classes=[0],
                                     device=self.device, verbose=False)  # FP32 default; never FP16 on Pascal
        per_tile = [_to_detections(r, t.x1, t.y1) for r, t in zip(results, tiles)]
        fine = merge(per_tile, tiles, w, h)
        if not self.coarse_imgsz:
            return fine
        coarse = _to_detections(self.model.predict(image, imgsz=self.coarse_imgsz, conf=self.conf, iou=self.iou,
                                                   classes=[0], device=self.device, verbose=False)[0])
        if regions and len(coarse):
            # Only people overlapping the tiled area; zones are decided after tracking.
            near = np.array([any(b[0] < t.x2 and b[2] > t.x1 and b[1] < t.y2 and b[3] > t.y1 for t in tiles)
                             for b in coarse.xyxy])
            coarse = coarse.subset(near)
        return fuse_scales(fine, coarse)
