"""Event-level evaluation against labels/ (shoplift.annotation format).

  python -m shoplift.evaluate --runs outputs/p0_v2

An event is one event_id: its conceal intervals (or a missed event with no
track). It counts as detected if any alert of that video falls in
[start - pre_s, end + post_s] and, when both carry boxes, near the person's box
at that time. Alerts matching no event are false alerts; the false-alert rate
uses only videos whose labels are marked complete. Recall is reported overall
and by visibility (an event is occluded if any of its conceal time is).
"""
import argparse
import json
from math import exp, factorial
from pathlib import Path
from typing import Dict, List

import numpy as np

from shoplift.annotation import load, value_at
from shoplift.registry import load_registry

ROOT = Path(__file__).resolve().parent.parent


def _foot(b):
    return np.array([(b[0] + b[2]) / 2, b[3]])


def events_of(L) -> List[Dict]:
    out: Dict[str, Dict] = {}
    for p in L.persons:
        for s in p.phase:
            if s.value != "conceal":
                continue
            e = out.setdefault(s.event_id, {"event_id": s.event_id, "start_s": s.start_s, "end_s": s.end_s,
                                            "person": p, "visibility": "visible", "missed": False})
            e["start_s"], e["end_s"] = min(e["start_s"], s.start_s), max(e["end_s"], s.end_s)
            for v in p.visibility:
                if v.value != "visible" and v.start_s < s.end_s and v.end_s > s.start_s:
                    e["visibility"] = v.value
    for m in L.missed_events:
        out.setdefault(m.event_id, {"event_id": m.event_id, "start_s": m.start_s, "end_s": m.end_s,
                                    "person": None, "box": m.box, "visibility": "missed_detection", "missed": True})
    return list(out.values())


def _person_box_at(p, t):
    if p is None or not p.boxes:
        return None
    ts = np.array([b[0] for b in p.boxes])
    return p.boxes[int(np.argmin(abs(ts - t)))][1:]


def poisson_upper(k: int, conf: float = 0.95) -> float:
    target = 1 - conf
    cdf = lambda lam: sum(exp(-lam) * lam ** i / factorial(i) for i in range(k + 1))
    lo, hi = 0.0, 10.0 + 5 * k
    for _ in range(100):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if cdf(mid) > target else (lo, mid)
    return hi


def evaluate(runs_dir: Path, labels_dir: Path = ROOT / "labels", pre_s: float = 1.0, post_s: float = 10.0,
             max_dist_px: float = 400.0, include_holdout: bool = True) -> Dict:
    reg = load_registry(labels_dir / "videos.json")
    per_event, false_alerts, hours = [], 0, 0.0
    for e in reg.values():
        lp = labels_dir / f"{e.video_key}.json"
        af = Path(runs_dir) / f"{e.name}_alerts.jsonl"
        if not lp.is_file() or not af.is_file() or (e.holdout and not include_holdout):
            continue
        L = load(lp)
        alerts = [json.loads(x) for x in af.read_text(encoding="utf-8").splitlines() if x.strip()]
        used = set()
        for ev in events_of(L):
            hit = None
            for k, a in enumerate(alerts):
                if not ev["start_s"] - pre_s <= a["t"] <= ev["end_s"] + post_s:
                    continue
                ref = ev.get("box") or _person_box_at(ev["person"], a["t"])
                if ref is not None and a.get("bbox") and np.linalg.norm(_foot(ref) - _foot(a["bbox"])) > max_dist_px:
                    continue
                if hit is None or a["t"] < alerts[hit]["t"]:
                    hit = k
            if hit is not None:
                used.add(hit)
            per_event.append({"video": e.name, "event_id": ev["event_id"], "holdout": e.holdout,
                              "visibility": ev["visibility"], "start_s": ev["start_s"], "end_s": ev["end_s"],
                              "detected": hit is not None,
                              "delay_s": alerts[hit]["t"] - ev["start_s"] if hit is not None else None})
        if L.complete:
            false_alerts += sum(1 for k in range(len(alerts)) if k not in used)
            s = Path(runs_dir) / f"{e.name}_summary.json"
            span = json.loads(s.read_text(encoding="utf-8")).get("source_span_s") if s.is_file() else None
            hours += (span or (e.frame_count / e.nominal_fps if e.nominal_fps else 0)) / 3600
    delays = [x["delay_s"] for x in per_event if x["detected"]]
    by_vis = {}
    for x in per_event:
        b = by_vis.setdefault(x["visibility"], {"events": 0, "detected": 0})
        b["events"] += 1
        b["detected"] += int(x["detected"])
    return {
        "events": len(per_event), "detected": sum(x["detected"] for x in per_event),
        "recall": (sum(x["detected"] for x in per_event) / len(per_event)) if per_event else None,
        "recall_by_visibility": by_vis,
        "median_delay_s": float(np.median(delays)) if delays else None,
        "complete_hours": hours, "false_alerts": false_alerts,
        "false_alerts_per_hour": false_alerts / hours if hours else None,
        "false_alerts_per_hour_95_upper": poisson_upper(false_alerts) / hours if hours else None,
        "per_event": per_event,
        "note": "Small samples: report the upper bound, not the point estimate.",
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--labels", type=Path, default=ROOT / "labels")
    ap.add_argument("--pre-s", type=float, default=1.0)
    ap.add_argument("--post-s", type=float, default=10.0)
    ap.add_argument("--exclude-holdout", action="store_true")
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    r = evaluate(a.runs, a.labels, a.pre_s, a.post_s, include_holdout=not a.exclude_holdout)
    text = json.dumps(r, indent=2, default=str)
    print(text)
    if a.out:
        a.out.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    main()
