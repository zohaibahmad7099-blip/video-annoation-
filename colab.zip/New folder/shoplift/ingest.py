"""Frame sources that carry a real timestamp with every frame.

Files: the decoder's presentation time (CAP_PROP_POS_MSEC), which is correct for
variable-frame-rate clips. Live: monotonic time at capture in the reader thread,
so frames dropped by a slow consumer never compress the time axis.
"""
import os
import queue
import threading
import time
from dataclasses import dataclass
from typing import Iterator, Optional
from urllib.parse import quote

import numpy as np

# Must be set before cv2 opens any FFmpeg capture. TCP avoids UDP packet loss
# smearing 5120x1520 frames; stimeout (microseconds) bounds a dead socket.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp|stimeout;5000000")
import cv2  # noqa: E402


@dataclass
class Frame:
    image: np.ndarray
    timestamp_s: float   # seconds since source start (files) or since open (live)
    index: int           # decoded frame index (not processed-frame count)


def is_stream(source: str) -> bool:
    return "://" in str(source)


def milesight_rtsp_url(host: str, username: str, password: str, stream: str = "main", port: int = 554) -> str:
    """Milesight paths are /main, /sub, /third (check the camera's RTSP page)."""
    if stream not in ("main", "sub", "third"):
        raise ValueError("stream must be 'main', 'sub' or 'third'")
    auth = f"{quote(username, safe='')}:{quote(password, safe='')}@" if username else ""
    return f"rtsp://{auth}{host}:{port}/{stream}"


def _open(source: str, hw_decode: bool):
    if hw_decode:
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG,
                               [cv2.CAP_PROP_HW_ACCELERATION, cv2.VIDEO_ACCELERATION_ANY])
    else:
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
    return cap


class FileSource:
    def __init__(self, path: str, hw_decode: bool = False):
        self.path = str(path)
        self.cap = _open(self.path, hw_decode)
        if not self.cap.isOpened():
            raise IOError(f"Cannot open video: {self.path}")
        self.nominal_fps = float(self.cap.get(cv2.CAP_PROP_FPS) or 0.0)
        self.frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)

    def __iter__(self) -> Iterator[Frame]:
        index, last_t = 0, -1.0
        try:
            while True:
                ok, image = self.cap.read()
                if not ok:
                    return
                t = self.cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
                # Some containers report 0 or repeats; fall back to nominal spacing
                # but never let time run backwards.
                if not np.isfinite(t) or t <= last_t:
                    step = 1.0 / self.nominal_fps if self.nominal_fps > 0 else 0.04
                    t = last_t + step if last_t >= 0 else 0.0
                last_t = t
                yield Frame(image, t, index)
                index += 1
        finally:
            self.cap.release()

    def close(self):
        self.cap.release()


class LiveSource:
    """Reader thread keeps only the newest frame; reconnects with backoff."""

    def __init__(self, url: str, hw_decode: bool = False, max_backoff_s: float = 30.0,
                 first_frame_timeout_s: float = 15.0):
        self.url = url
        self.hw_decode = hw_decode
        self.max_backoff_s = max_backoff_s
        self.first_frame_timeout_s = first_frame_timeout_s
        self.frames: "queue.Queue[Frame]" = queue.Queue(maxsize=1)
        self.stop_event = threading.Event()
        self.t0 = time.monotonic()
        self.decoded = 0
        self.dropped = 0
        self.reconnects = 0
        self.thread = threading.Thread(target=self._loop, name="live-source", daemon=True)

    def start(self):
        self.thread.start()
        return self

    def _loop(self):
        backoff = 1.0
        while not self.stop_event.is_set():
            cap = _open(self.url, self.hw_decode)
            if not cap.isOpened():
                cap.release()
                self.reconnects += 1
                print(f"[Live] Cannot open stream; retry in {backoff:.0f}s")
                if self.stop_event.wait(backoff):
                    return
                backoff = min(backoff * 2, self.max_backoff_s)
                continue
            backoff = 1.0
            failures = 0
            while not self.stop_event.is_set():
                ok, image = cap.read()
                t = time.monotonic() - self.t0
                if not ok or image is None:
                    failures += 1
                    if failures > 25:
                        print("[Live] Stream stalled; reconnecting")
                        self.reconnects += 1
                        break
                    continue
                failures = 0
                frame = Frame(image, t, self.decoded)
                self.decoded += 1
                try:
                    self.frames.put_nowait(frame)
                except queue.Full:
                    try:
                        self.frames.get_nowait()
                        self.dropped += 1
                    except queue.Empty:
                        pass
                    self.frames.put_nowait(frame)
            cap.release()

    def __iter__(self) -> Iterator[Frame]:
        deadline = time.monotonic() + self.first_frame_timeout_s
        got_any = False
        while not self.stop_event.is_set():
            try:
                frame = self.frames.get(timeout=1.0)
            except queue.Empty:
                if not got_any and time.monotonic() > deadline:
                    raise IOError(f"No frames from stream within {self.first_frame_timeout_s:.0f}s")
                continue
            got_any = True
            yield frame

    def close(self):
        self.stop_event.set()
        if self.thread.is_alive():
            self.thread.join(timeout=3.0)


def open_source(source: str, hw_decode: bool = False):
    return LiveSource(source, hw_decode).start() if is_stream(source) else FileSource(source, hw_decode)


class CadenceSampler:
    """Admit frames on a fixed time grid (e.g. 12.5 Hz) using frame timestamps."""

    def __init__(self, hz: float):
        if hz <= 0:
            raise ValueError("analysis hz must be positive")
        self.period = 1.0 / hz
        self.next_t: Optional[float] = None

    def admit(self, t: float) -> bool:
        if self.next_t is None:
            self.next_t = t + self.period
            return True
        # Quarter-period tolerance absorbs timestamp jitter without admitting neighbours.
        tol = 0.25 * self.period
        if t + tol >= self.next_t:
            # If we fell behind (slow consumer), resynchronise instead of bursting.
            self.next_t = max(self.next_t + self.period, t + self.period - tol)
            return True
        return False
