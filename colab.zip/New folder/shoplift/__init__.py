"""P0 shoplifting pipeline: timestamped ingest, tiled pose, tracking, alert policy, evaluation.

The legacy `src/` pipeline is left intact for A/B comparison.
"""
