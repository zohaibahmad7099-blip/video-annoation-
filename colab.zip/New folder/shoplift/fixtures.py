"""Shelf-change evidence for thefts the camera cannot see happen.

When a shopper's own body hides their hands (back to the camera at a fixture
that faces the camera), the act is unobservable but its result often is: an
item missing from the fixture. Per fixture we keep a clean reference image while
nobody blocks it, freeze it when someone arrives, and when the fixture has been
clear for `settle_s` compare a fresh image with it. Pixels hidden by a person
are excluded from both sides.
"""
import json
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np

from shoplift.zones import CameraZones


@dataclass
class FixtureConfig:
    sample_every_s: float = 0.4      # reference / settle sampling period
    ref_samples: int = 5             # median of this many clean samples
    settle_s: float = 1.2            # fixture must stay clear this long before "after"
    occupied_overlap: float = 0.02   # fraction of fixture covered by people to count as occupied
    box_pad: float = 0.10            # pad person boxes (arms, shadows)
    diff_thresh: float = 28.0        # per-pixel colour change (0-255) after gain compensation
    min_blob_px: int = 150           # smallest changed blob that counts (removes codec speckle)
    min_change_frac: float = 0.004   # fixture area fraction changed to call it a change
    min_dwell_s: float = 3.0         # visitor dwell needed for a candidate
    candidate_to_alerts: bool = True  # also write candidates to <run>_alerts.jsonl
    candidate_to_nx: bool = False     # send candidates to Nx Witness (off until validated)


def fixture_change(before: np.ndarray, after: np.ndarray, valid: np.ndarray, cfg: FixtureConfig) -> Dict:
    """Changed area between two BGR crops over `valid` pixels.

    Gain compensation per channel absorbs camera AGC and lighting drift; small
    blobs (codec noise) are discarded. Returns metrics and the change mask.
    """
    b = cv2.GaussianBlur(before.astype(np.float32), (5, 5), 0)
    a = cv2.GaussianBlur(after.astype(np.float32), (5, 5), 0)
    v = valid.astype(bool)
    if v.sum() < 100:
        return {"valid_px": int(v.sum()), "changed_frac": 0.0, "largest_blob_px": 0, "mask": np.zeros_like(valid)}
    gain = b[v].mean(axis=0) / np.maximum(a[v].mean(axis=0), 1e-3)
    diff = np.abs(b - a * gain).max(axis=2)
    changed = ((diff > cfg.diff_thresh) & v).astype(np.uint8)
    changed = cv2.morphologyEx(changed, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(changed, connectivity=8)
    keep = np.zeros_like(changed)
    largest = 0
    for i in range(1, n):
        area = int(stats[i, cv2.CC_STAT_AREA])
        if area >= cfg.min_blob_px:
            keep[labels == i] = 1
            largest = max(largest, area)
    return {"valid_px": int(v.sum()), "changed_frac": float(keep.sum() / v.sum()),
            "largest_blob_px": largest, "mask": keep}


class _Fixture:
    def __init__(self, name: str, polygon: np.ndarray, frame_w: int, frame_h: int):
        self.name = name
        x1, y1 = np.floor(polygon.min(axis=0)).astype(int)
        x2, y2 = np.ceil(polygon.max(axis=0)).astype(int)
        self.x1, self.y1 = max(0, x1), max(0, y1)
        self.x2, self.y2 = min(frame_w, x2), min(frame_h, y2)
        self.mask = np.zeros((self.y2 - self.y1, self.x2 - self.x1), np.uint8)
        cv2.fillPoly(self.mask, [np.round(polygon - [self.x1, self.y1]).astype(np.int32)], 1)
        self.area = int(self.mask.sum())
        self.state = "free"
        self.ref: deque = deque()
        self.settle: List = []
        self.last_sample = -np.inf
        self.clear_since: Optional[float] = None
        self.before = None
        self.t_arrive = None
        self.t_last_occupied = None
        self.visitors: Dict[int, Dict] = {}


class FixtureMonitor:
    def __init__(self, fixtures: CameraZones, cfg: FixtureConfig, out_dir: Path, run_name: str):
        self.cfg = cfg
        self.base = fixtures
        self.items: Optional[List[_Fixture]] = None
        self.out_dir = Path(out_dir) / f"{run_name}_fixtures"
        self.events_path = Path(out_dir) / f"{run_name}_fixture_events.jsonl"
        self.events_path.write_text("", encoding="utf-8")
        self.events: List[Dict] = []

    def _occluder_mask(self, f: _Fixture, boxes: List[np.ndarray]) -> np.ndarray:
        occ = np.zeros_like(f.mask)
        for b in boxes:
            w, h = b[2] - b[0], b[3] - b[1]
            x1 = int(max(f.x1, b[0] - self.cfg.box_pad * w)) - f.x1
            y1 = int(max(f.y1, b[1] - self.cfg.box_pad * h)) - f.y1
            x2 = int(min(f.x2, b[2] + self.cfg.box_pad * w)) - f.x1
            y2 = int(min(f.y2, b[3] + self.cfg.box_pad * h)) - f.y1
            if x2 > x1 and y2 > y1:
                occ[y1:y2, x1:x2] = 1
        return occ

    def update(self, t: float, image: np.ndarray, all_tracks: List[Dict]) -> List[Dict]:
        """all_tracks: every tracked person (zone or not) - any of them can block a fixture."""
        cfg = self.cfg
        if self.items is None:
            h, w = image.shape[:2]
            cam = self.base.for_frame(w, h)
            self.items = [_Fixture(z.name, z.polygon, w, h) for z in cam.zones]
        boxes = [tr["bbox"] for tr in all_tracks]
        emitted = []
        for f in self.items:
            occ = self._occluder_mask(f, boxes)
            covered = float((occ & f.mask).sum()) / max(f.area, 1)
            occupied = covered > cfg.occupied_overlap
            crop = image[f.y1:f.y2, f.x1:f.x2]
            if occupied:
                if f.state == "free":
                    f.state, f.t_arrive, f.visitors = "occupied", t, {}
                    f.before = np.median(np.stack(f.ref), axis=0).astype(np.uint8) if f.ref else None
                elif f.state == "settling":
                    f.state = "occupied"      # someone blocked it again before it settled
                f.settle, f.clear_since, f.t_last_occupied = [], None, t
                for tr in all_tracks:
                    o = self._occluder_mask(f, [tr["bbox"]])
                    if (o & f.mask).sum() > 0:
                        v = f.visitors.setdefault(tr["track_id"], {"first": t, "last": t, "n": 0, "back": 0,
                                                                   "max_score": None, "bbox": None})
                        v["last"], v["n"] = t, v["n"] + 1
                        kp = tr["keypoints"]
                        # Back to camera: face joints unseen (nose, both eyes).
                        v["back"] += int(kp[0, 2] < 0.3 and kp[1, 2] < 0.3 and kp[2, 2] < 0.3)
                        s = tr.get("score")
                        if s is not None:
                            v["max_score"] = s if v["max_score"] is None else max(v["max_score"], s)
                        v["bbox"] = [float(x) for x in tr["bbox"]]
                continue
            # Not occupied now
            if f.state == "occupied":
                f.state, f.clear_since, f.settle = "settling", t, []
            if t - f.last_sample >= cfg.sample_every_s:
                f.last_sample = t
                if f.state == "free":
                    f.ref.append(crop.copy())
                    while len(f.ref) > cfg.ref_samples:
                        f.ref.popleft()
                elif f.state == "settling":
                    f.settle.append(crop.copy())
            if f.state == "settling" and t - f.clear_since >= cfg.settle_s and len(f.settle) >= 3:
                ev = self._finish(f, t)
                if ev:
                    emitted.append(ev)
        return emitted

    def _finish(self, f: _Fixture, t: float) -> Optional[Dict]:
        cfg = self.cfg
        after = np.median(np.stack(f.settle), axis=0).astype(np.uint8)
        f.ref = deque(f.settle[-cfg.ref_samples:])
        f.state, f.settle = "free", []
        if f.before is None:
            return None
        m = fixture_change(f.before, after, f.mask, cfg)
        visitors = []
        for tid, v in f.visitors.items():
            dwell = v["last"] - v["first"]
            visitors.append({"track_id": tid, "dwell_s": round(dwell, 2),
                             "back_facing_frac": round(v["back"] / max(v["n"], 1), 2),
                             "max_score": v["max_score"], "bbox": v["bbox"]})
        visitors.sort(key=lambda v: -v["dwell_s"])
        changed = m["changed_frac"] >= cfg.min_change_frac
        main = visitors[0] if visitors else None
        candidate = bool(changed and main and main["dwell_s"] >= cfg.min_dwell_s)
        ev = {"fixture": f.name, "t_arrive": round(f.t_arrive, 2), "t_leave": round(f.t_last_occupied, 2),
              "t_evaluated": round(t, 2), "changed_frac": round(m["changed_frac"], 4),
              "largest_blob_px": m["largest_blob_px"], "valid_px": m["valid_px"],
              "changed": changed, "candidate": candidate, "visitors": visitors}
        self.out_dir.mkdir(parents=True, exist_ok=True)
        vis = np.hstack([f.before, after, cv2.cvtColor((m["mask"] * 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)])
        name = f"{f.name}_{f.t_arrive:07.2f}s.jpg"
        cv2.imwrite(str(self.out_dir / name), vis)
        ev["image"] = name
        with open(self.events_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(ev) + "\n")
        self.events.append(ev)
        return ev
