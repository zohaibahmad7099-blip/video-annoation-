"""Turn noisy per-window scores into sparse alerts.

The legacy loop alerted on any single 1 s window above threshold. Here a person
must hold a high median score for a sustained period, and the cooldown is also
spatial, so a track-ID switch cannot re-trigger the same incident.
"""
from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple

import numpy as np


@dataclass
class AlertPolicyConfig:
    threshold: float = 0.6
    window_s: float = 3.0           # scores considered
    min_scores: int = 6             # require this many scored windows in it
    min_fraction_above: float = 0.6
    cooldown_s: float = 30.0
    spatial_cooldown_px: float = 300.0  # suppress re-alerts near a recent alert (ID switches)


class AlertPolicy:
    def __init__(self, cfg: AlertPolicyConfig = AlertPolicyConfig()):
        self.cfg = cfg
        self.scores: Dict[int, Deque[Tuple[float, float]]] = {}
        self.recent: List[Tuple[float, int, np.ndarray]] = []  # (t, track_id, foot point)

    def reset(self):
        self.scores.clear()
        self.recent.clear()

    def update(self, track_id: int, t: float, score: Optional[float], foot: np.ndarray) -> Optional[Dict]:
        c = self.cfg
        q = self.scores.setdefault(track_id, deque())
        if score is not None and np.isfinite(score):
            q.append((t, float(score)))
        while q and t - q[0][0] > c.window_s:
            q.popleft()
        self.recent = [r for r in self.recent if t - r[0] < c.cooldown_s]
        if len(q) < c.min_scores:
            return None
        s = np.array([v for _, v in q])
        median = float(np.median(s))
        frac = float((s >= c.threshold).mean())
        if median < c.threshold or frac < c.min_fraction_above:
            return None
        for _, tid, p in self.recent:
            if tid == track_id or np.linalg.norm(p - foot) < c.spatial_cooldown_px:
                return None
        self.recent.append((t, track_id, foot.copy()))
        return {"t": t, "track_id": track_id, "median_score": median, "fraction_above": frac, "n": len(s)}

    def forget(self, t: float):
        """Drop score histories whose newest entry is older than the window."""
        for tid in list(self.scores):
            q = self.scores[tid]
            if not q or t - q[-1][0] > self.cfg.window_s:
                del self.scores[tid]
