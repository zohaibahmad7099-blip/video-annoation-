"""Headless labelling session: the editing model behind labelling_studio.py.

Everything annotate.py can do, as methods with undo and an atomic save after
every change, so the GUI only draws and forwards clicks/keys. Differences from
annotate.py, all deliberate:

  * Persons are drawn from their own box trajectory (the reviewed snapshot), not
    from track ids, so labels stay correct on screen when the tracks CSV changed.
  * When the reference tracks changed since labelling, track-based edits are
    blocked until `relink_by_overlap` re-attaches persons to the new track ids
    (annotate.py silently adopted the new file, leaving stale ids).
  * Marking complete runs the checks *as complete* first (annotate.py linted
    with complete=False, so unlabelled time passed and the file then failed).
  * An edit that breaks a complete video demotes it to incomplete, so
    `complete` always means "passes the checks".
  * Frame and track times are matched by nearest time, not float equality.
"""
import copy
import csv
import io
import json
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from shoplift.annotation import (PHASES, VISIBILITY, MissedEvent, Person, Segment, VideoLabels, paint,
                                 save, value_at)
from shoplift.label_readiness import (Workspace, check_video, completion_check, file_sha256, load_labels,
                                      scan_label_files)
from shoplift.registry import VideoEntry, load_registry

PHASE_COLORS = {"normal": "#969696", "inspect": "#00c8ff", "pick": "#ffc800", "suspicious": "#ff2020",
                "basket": "#00c800", "return": "#c800c8", "unknown": "#3c3c3c"}
VIS_COLORS = {"visible": "#c8c8c8", "hands_occluded": "#ff8c00", "body_occluded": "#a00000"}
PERSON_COLORS = ["#4fc3f7", "#aed581", "#ffb74d", "#f06292", "#ba68c8", "#4db6ac", "#fff176", "#7986cb",
                 "#e57373", "#81c784", "#ffd54f", "#64b5f6"]
BOX_TOL_S = 0.06     # same tolerance dataset_build uses to match a box to a time
MIN_IOU = 0.5


def person_color(person_id: str) -> str:
    digits = "".join(c for c in person_id if c.isdigit())
    return PERSON_COLORS[(int(digits) - 1 if digits else hash(person_id)) % len(PERSON_COLORS)]


def iou(a, b) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter + 1e-9)


class Cancelled(Exception):
    pass


# ---------------------------------------------------------------- tracks
class Tracks:
    """Reference tracks CSV (pipeline output) read with the csv module."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.sha256 = file_sha256(self.path)
        t, tid, box, conf = [], [], [], []
        with open(self.path, newline="", encoding="utf-8") as f:
            rd = csv.reader(f)
            head = next(rd)
            ix = [head.index(c) for c in ("timestamp_s", "track_id", "x1", "y1", "x2", "y2", "conf")]
            for row in rd:
                if not row:
                    continue
                t.append(round(float(row[ix[0]]), 3))
                tid.append(int(float(row[ix[1]])))
                box.append([float(row[i]) for i in ix[2:6]])
                conf.append(float(row[ix[6]]) if row[ix[6]] else 0.0)
        order = np.argsort(np.array(t, float), kind="stable")
        self.t = np.array(t, float)[order]
        self.tid = np.array(tid, int)[order]
        self.box = np.array(box, float).reshape(-1, 4)[order]
        self.conf = np.array(conf, float)[order]
        self.ids = sorted(set(self.tid.tolist()))

    @property
    def max_time(self) -> float:
        return float(self.t[-1]) if len(self.t) else 0.0

    def at(self, t: float, tol: float) -> List[Tuple[int, np.ndarray]]:
        lo, hi = np.searchsorted(self.t, t - tol), np.searchsorted(self.t, t + tol, side="right")
        best: Dict[int, Tuple[float, int]] = {}
        for i in range(lo, hi):
            d = abs(self.t[i] - t)
            if self.tid[i] not in best or d < best[self.tid[i]][0]:
                best[int(self.tid[i])] = (d, i)
        return [(k, self.box[i]) for k, (_, i) in best.items()]

    def boxes_for(self, track_ids) -> List[List[float]]:
        """Same result as annotate.boxes_for: one box per time, highest confidence wins."""
        sel = np.isin(self.tid, list(track_ids))
        best: Dict[float, int] = {}
        for i in np.flatnonzero(sel):
            t = self.t[i]
            if t not in best or self.conf[i] >= self.conf[best[t]]:
                best[t] = i
        return [[round(float(t), 3), *[round(float(v), 1) for v in self.box[i]]] for t, i in sorted(best.items())]


def tracks_state(ws: Workspace, name: str) -> str:
    """'ok', 'missing' or 'unfinished' (CSV without the summary the pipeline writes last)."""
    if not ws.tracks_csv(name).is_file():
        return "missing"
    return "ok" if ws.summary_json(name).is_file() else "unfinished"


# ---------------------------------------------------------------- frames
class FrameStore:
    """JPEG display frames on the pipeline's cadence grid (as annotate.decode_frames)."""

    def __init__(self):
        self.times = np.zeros(0)
        self.jpegs: List[bytes] = []
        self.src_w = self.src_h = self.frame_w = self.frame_h = 0

    def __len__(self):
        return len(self.jpegs)

    def decode(self, path: Path, hz: float, width: int,
               progress: Optional[Callable[[int, int], None]] = None,
               cancel: Optional[Callable[[], bool]] = None) -> "FrameStore":
        import cv2
        from shoplift.ingest import CadenceSampler, FileSource
        src, sampler = FileSource(str(path)), CadenceSampler(hz)
        total = max(src.frame_count, 1)
        times, jpegs = [], []
        try:
            for f in src:
                if cancel and cancel():
                    raise Cancelled()
                if progress and f.index % 20 == 0:
                    progress(f.index, total)
                if not sampler.admit(f.timestamp_s):
                    continue
                h, w = f.image.shape[:2]
                out_w = min(width, w) if width else w
                small = f.image if out_w == w else cv2.resize(
                    f.image, (out_w, int(round(h * out_w / w))), interpolation=cv2.INTER_AREA)
                times.append(round(f.timestamp_s, 3))
                jpegs.append(cv2.imencode(".jpg", small, [cv2.IMWRITE_JPEG_QUALITY, 85])[1].tobytes())
                self.src_w, self.src_h = w, h
                self.frame_h, self.frame_w = small.shape[:2]
        finally:
            src.close()
        if not jpegs:
            raise IOError(f"No frames decoded from {path}")
        self.times, self.jpegs = np.array(times, float), jpegs
        return self

    def index_of(self, t: float) -> int:
        i = int(np.searchsorted(self.times, t))
        if i <= 0:
            return 0
        if i >= len(self.times):
            return len(self.times) - 1
        return i if self.times[i] - t < t - self.times[i - 1] else i - 1


# ---------------------------------------------------------------- session
class LabelSession:
    def __init__(self, ws: Workspace, entry: VideoEntry, reviewer: str = "", hz: float = 10.0,
                 tracks: Optional[Tracks] = None):
        self.ws, self.entry, self.hz, self.step = ws, entry, hz, 1.0 / hz
        self.label_path = ws.label_path(entry.name)
        by_key, _, _ = scan_label_files(ws.labels_dir)
        existing = self.label_path if self.label_path.is_file() else by_key.get(entry.name)
        self.loaded_from = existing
        if existing is not None:
            self.L = load_labels(existing)
            self.L.video_key = self.L.video_name = entry.name
        else:
            self.L = VideoLabels(entry.name, entry.name, entry.sha256)
        if self.L.sha256 != entry.sha256:
            raise ValueError(f"{existing.name} was made for different video content than the registered "
                             f"'{entry.name}' (hash differs)")
        self.tracks = tracks if tracks is not None else (
            Tracks(ws.tracks_csv(entry.name)) if ws.tracks_csv(entry.name).is_file() else None)
        self.tracks_match = True
        if self.tracks is not None:
            ref = self.L.reference_tracks_sha256
            has_links = any(p.track_ids for p in self.L.persons)
            self.tracks_match = (not ref) or ref == self.tracks.sha256 or not has_links
            if self.tracks_match:
                self._adopt_tracks()
        if reviewer:
            self.L.reviewer = reviewer
        self.undo_stack: List[VideoLabels] = []
        self._box_cache: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
        self.dirty_since_load = False

    # ------------------------------------------------------------ state
    def _adopt_tracks(self):
        self.L.reference_tracks = self.ws.rel(self.tracks.path)
        self.L.reference_tracks_sha256 = self.tracks.sha256

    def _checkpoint(self):
        self.undo_stack.append(copy.deepcopy(self.L))
        del self.undo_stack[:-100]

    def _commit(self, msg: str) -> str:
        self._box_cache.clear()
        if self.L.complete:
            errs, _ = completion_check(self.L)
            if errs:
                self.L.complete = False
                msg += f" - video no longer complete ({len(errs)} problem(s)); fix and mark complete again"
        save(self.L, self.label_path)
        self.dirty_since_load = True
        return msg

    def save_now(self) -> str:
        save(self.L, self.label_path)
        return f"saved {self.label_path.name}"

    def undo(self) -> str:
        if not self.undo_stack:
            return "nothing to undo"
        prev = self.undo_stack.pop()
        self.L.persons, self.L.missed_events, self.L.complete = prev.persons, prev.missed_events, prev.complete
        self.L.reference_tracks, self.L.reference_tracks_sha256 = prev.reference_tracks, prev.reference_tracks_sha256
        self.tracks_match = self.tracks is None or not any(p.track_ids for p in self.L.persons) or \
            self.L.reference_tracks_sha256 in ("", self.tracks.sha256)
        return self._commit("undone")

    def report(self):
        reg = load_registry(self.ws.registry_path)
        return check_video(self.ws, self.entry.name, reg.get(self.entry.name), self.label_path, self.L)

    # ------------------------------------------------------------ queries
    def person(self, pid: Optional[str]) -> Optional[Person]:
        return next((p for p in self.L.persons if p.person_id == pid), None) if pid else None

    def _arrays(self, p: Person):
        c = self._box_cache.get(p.person_id)
        if c is None:
            b = np.array(p.boxes, float).reshape(-1, 5)
            c = self._box_cache[p.person_id] = (b[:, 0], b[:, 1:])
        return c

    def person_box_at(self, p: Person, t: float, tol: float = BOX_TOL_S) -> Optional[np.ndarray]:
        ts, bs = self._arrays(p)
        if not len(ts):
            return None
        i = int(np.searchsorted(ts, t))
        cand = [j for j in (i - 1, i) if 0 <= j < len(ts) and abs(ts[j] - t) <= tol]
        return bs[min(cand, key=lambda j: abs(ts[j] - t))] if cand else None

    def visible_at(self, t: float):
        """(persons [(Person, box)], unlinked tracks [(tid, box)]) to draw at time t."""
        tol = self.step / 2
        persons = [(p, b) for p in self.L.persons if (b := self.person_box_at(p, t, max(tol, BOX_TOL_S))) is not None]
        free = []
        if self.tracks is not None:
            for tid, box in self.tracks.at(t, tol):
                owner = self.L.person_of_track(tid) if self.tracks_match else None
                if owner is not None and any(p is owner for p, _ in persons):
                    continue
                if any(iou(box, pb) >= MIN_IOU for _, pb in persons):
                    continue
                free.append((tid, box))
        return persons, free

    def range(self, t: float, mark: Optional[float]) -> Tuple[float, float]:
        a = mark if mark is not None else t
        return round(min(a, t), 3), round(max(a, t) + self.step, 3)

    def coverage(self, p: Person) -> Tuple[float, float]:
        """Fraction of the person's span labelled with a phase / a visibility."""
        if not p.span:
            return 0.0, 0.0
        t0, t1 = p.span[0], p.span[1] + self.step
        out = []
        for segs in (p.phase, p.visibility):
            cov = sum(max(0.0, min(s.end_s, t1) - max(s.start_s, t0)) for s in segs)
            out.append(min(1.0, cov / max(t1 - t0, 1e-6)))
        return out[0], out[1]

    def known_actor_ids(self) -> List[str]:
        ids = set()
        by_key, _, _ = scan_label_files(self.ws.labels_dir)
        for key, path in by_key.items():
            if key == self.entry.name:
                continue
            try:
                ids |= {p.get("actor_id", "") for p in json.loads(path.read_text(encoding="utf-8")).get("persons", [])}
            except (OSError, ValueError):
                pass
        ids |= {p.actor_id for p in self.L.persons}
        ids.discard("")
        return sorted(ids, key=lambda a: (len(a), a))

    # ------------------------------------------------------------ persons
    def _need_tracks(self):
        if self.tracks is None:
            raise ValueError("no reference tracks for this video")
        if not self.tracks_match:
            raise ValueError("reference tracks changed since these labels were made - "
                             "press 'Re-link tracks' first")

    def new_person(self, track_id: int) -> Tuple[str, str]:
        self._need_tracks()
        if self.L.person_of_track(track_id):
            raise ValueError(f"track #{track_id} already belongs to {self.L.person_of_track(track_id).person_id}")
        self._checkpoint()
        p = Person(self.L.next_person_id(), [track_id], self.tracks.boxes_for([track_id]))
        self.L.persons.append(p)
        return p.person_id, self._commit(f"new person {p.person_id} from track #{track_id}")

    def link(self, pid: str, track_id: int) -> str:
        self._need_tracks()
        owner = self.L.person_of_track(track_id)
        if owner:
            raise ValueError(f"track #{track_id} already belongs to {owner.person_id} (unlink it first)")
        self._checkpoint()
        p = self.person(pid)
        p.track_ids.append(track_id)
        p.boxes = self.tracks.boxes_for(p.track_ids)
        return self._commit(f"linked track #{track_id} to {pid}")

    def unlink(self, track_id: int) -> str:
        self._need_tracks()
        p = self.L.person_of_track(track_id)
        if not p:
            raise ValueError(f"track #{track_id} is not linked to anyone")
        self._checkpoint()
        p.track_ids.remove(track_id)
        p.boxes = self.tracks.boxes_for(p.track_ids)
        extra = " (no tracks left - link one or delete the person)" if not p.track_ids else ""
        return self._commit(f"unlinked track #{track_id} from {p.person_id}{extra}")

    def delete_person(self, pid: str) -> str:
        self._checkpoint()
        self.L.persons = [p for p in self.L.persons if p.person_id != pid]
        return self._commit(f"deleted {pid}")

    def set_actor(self, pid: str, actor_id: str) -> str:
        actor_id = actor_id.strip().upper()
        clash = next((p.person_id for p in self.L.persons if p.person_id != pid and actor_id and p.actor_id == actor_id), None)
        if clash:
            raise ValueError(f"{clash} already has actor id {actor_id} in this video "
                             "(one individual = one person; link their tracks instead)")
        self._checkpoint()
        self.person(pid).actor_id = actor_id
        return self._commit(f"{pid} actor id = {actor_id or '-'}")

    def set_staff(self, pid: str, staff: bool) -> str:
        self._checkpoint()
        self.person(pid).is_staff = bool(staff)
        return self._commit(f"{pid} staff = {bool(staff)}")

    def set_note(self, pid: str, note: str) -> str:
        self._checkpoint()
        self.person(pid).note = note.strip()
        return self._commit(f"{pid} note saved")

    def set_reviewer(self, reviewer: str) -> str:
        if reviewer.strip() == self.L.reviewer:
            return ""
        self.L.reviewer = reviewer.strip()
        return self._commit(f"reviewer = {self.L.reviewer}")

    def relink_by_overlap(self) -> str:
        """Re-attach persons to the current tracks file by box overlap (boxes are kept)."""
        if self.tracks is None:
            raise ValueError("no reference tracks for this video")
        self._checkpoint()
        assign: Dict[int, str] = {}
        for tid in self.tracks.ids:
            idx = np.flatnonzero(self.tracks.tid == tid)
            votes: Dict[str, int] = {}
            for i in idx:
                best, best_iou = None, MIN_IOU
                for p in self.L.persons:
                    b = self.person_box_at(p, self.tracks.t[i])
                    if b is not None and (v := iou(b, self.tracks.box[i])) >= best_iou:
                        best, best_iou = p.person_id, v
                if best:
                    votes[best] = votes.get(best, 0) + 1
            if votes:
                pid, n = max(votes.items(), key=lambda kv: kv[1])
                if n >= 0.5 * len(idx):
                    assign[tid] = pid
        for p in self.L.persons:
            p.track_ids = sorted(t for t, pid in assign.items() if pid == p.person_id)
        self._adopt_tracks()
        self.tracks_match = True
        orphans = [p.person_id for p in self.L.persons if not p.track_ids]
        return self._commit(f"re-linked {len(assign)} track(s) by overlap" +
                            (f"; no matching track for {', '.join(orphans)} (boxes kept)" if orphans else ""))

    # ------------------------------------------------------------ timelines
    def paint_phase(self, pid: str, a: float, b: float, phase: str, event_id: str = "") -> str:
        if phase not in PHASES:
            raise ValueError(f"unknown phase {phase}")
        self._checkpoint()
        p = self.person(pid)
        p.phase = paint(p.phase, a, b, phase, event_id)
        return self._commit(f"{pid} {phase}{' ' + event_id if event_id else ''} {a:.2f}-{b:.2f}s")

    def paint_visibility(self, pid: str, a: float, b: float, value: str) -> str:
        if value not in VISIBILITY:
            raise ValueError(f"unknown visibility {value}")
        self._checkpoint()
        p = self.person(pid)
        p.visibility = paint(p.visibility, a, b, value)
        return self._commit(f"{pid} {value} {a:.2f}-{b:.2f}s")

    def fill_gaps(self, pid: str) -> str:
        """Annotate's F: unlabelled time in the person's span -> normal + visible."""
        p = self.person(pid)
        if not p or not p.span:
            raise ValueError("person has no box trajectory")
        self._checkpoint()
        t0, t1 = p.span[0], p.span[1] + self.step
        for name, default in (("phase", "normal"), ("visibility", "visible")):
            segs = getattr(p, name)
            cursor, filled = t0, list(segs)
            for s in sorted(segs, key=lambda s: s.start_s) + [None]:
                end = t1 if s is None else s.start_s
                if end - cursor > 1e-6:
                    filled = paint(filled, cursor, end, default)
                cursor = max(cursor, s.end_s) if s else cursor
            setattr(p, name, filled)
        return self._commit(f"{pid}: unlabelled time filled with normal + visible")

    def delete_segment(self, pid: str, kind: str, index: int) -> str:
        self._checkpoint()
        p = self.person(pid)
        segs = p.phase if kind == "phase" else p.visibility
        s = segs.pop(index)
        return self._commit(f"{pid}: removed {kind} {s.value} {s.start_s:.2f}-{s.end_s:.2f}s")

    def reset_person(self, pid: str) -> str:
        self._checkpoint()
        p = self.person(pid)
        p.phase, p.visibility = [], []
        return self._commit(f"{pid} labels reset")

    def reset_all(self) -> str:
        self._checkpoint()
        self.L.persons, self.L.missed_events, self.L.complete = [], [], False
        return self._commit("all labels reset")

    def add_missed(self, a: float, b: float, event_id: str, note: str) -> str:
        self._checkpoint()
        self.L.missed_events.append(MissedEvent(event_id or self.L.next_event_id(), a, b, note=note.strip()))
        return self._commit(f"missed event {self.L.missed_events[-1].event_id} {a:.2f}-{b:.2f}s")

    def delete_missed(self, index: int) -> str:
        self._checkpoint()
        m = self.L.missed_events.pop(index)
        return self._commit(f"removed missed event {m.event_id}")

    # ------------------------------------------------------------ completion
    def mark_complete(self) -> Tuple[bool, List[str], List[str]]:
        errs, warns = completion_check(self.L)
        if errs:
            return False, errs, warns
        self._checkpoint()
        self.L.complete = True
        self._commit("video marked COMPLETE")
        return True, [], warns

    def unmark_complete(self) -> str:
        self._checkpoint()
        self.L.complete = False
        return self._commit("video marked incomplete")

    # ------------------------------------------------------------ review video
    def export_review_video(self, frames: FrameStore, out: Path,
                            progress: Optional[Callable[[int, int], None]] = None) -> Path:
        import cv2
        first = cv2.imdecode(np.frombuffer(frames.jpegs[0], np.uint8), cv2.IMREAD_COLOR)
        h, w = first.shape[:2]
        writer = cv2.VideoWriter(str(out), cv2.VideoWriter_fourcc(*"mp4v"), self.hz, (w, h))
        if not writer.isOpened():
            raise IOError(f"cannot write {out}")
        scale = frames.frame_w / max(frames.src_w, 1)
        try:
            for i, t in enumerate(frames.times):
                img = cv2.imdecode(np.frombuffer(frames.jpegs[i], np.uint8), cv2.IMREAD_COLOR)
                persons, _ = self.visible_at(float(t))
                for p, box in persons:
                    b = (box * scale).astype(int)
                    hexc = person_color(p.person_id).lstrip("#")
                    col = tuple(int(hexc[k:k + 2], 16) for k in (4, 2, 0))
                    ph, vi = value_at(p.phase, float(t)), value_at(p.visibility, float(t))
                    lab = f"{p.person_id}: {ph.value if ph else '?'}" + (f" / {vi.value}" if vi else "") + \
                          (f" {ph.event_id}" if ph and ph.event_id else "")
                    cv2.rectangle(img, (b[0], b[1]), (b[2], b[3]), col, 2)
                    cv2.putText(img, lab, (b[0], max(18, b[1] - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, col, 2, cv2.LINE_AA)
                cv2.putText(img, f"t={t:6.2f}s", (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
                writer.write(img)
                if progress and i % 20 == 0:
                    progress(i, len(frames))
        finally:
            writer.release()
        return out


def jpeg_to_pil(data: bytes):
    from PIL import Image
    return Image.open(io.BytesIO(data))
