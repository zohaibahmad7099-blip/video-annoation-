"""P0 pipeline: timestamped frames -> fixed cadence -> tiled pose -> tracker -> scorer -> alert policy.

The behaviour scorer is pluggable. Until Stage A/B models are trained the legacy
random forest is wrapped as the scorer, so its results can be compared fairly
with correct timestamps, resolution and tracking.
"""
import csv
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

import cv2
import numpy as np

from shoplift.alerting import AlertPolicy, AlertPolicyConfig
from shoplift.fixtures import FixtureConfig, FixtureMonitor
from shoplift.ingest import CadenceSampler, LiveSource, is_stream, open_source
from shoplift.tiling import Detections, TiledPose
from shoplift.tracking import PersonTracker
from shoplift.zones import CameraZones

COCO17 = ["nose", "left_eye", "right_eye", "left_ear", "right_ear", "left_shoulder", "right_shoulder",
          "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip",
          "left_knee", "right_knee", "left_ankle", "right_ankle"]
SKELETON = [(5, 6), (5, 7), (7, 9), (6, 8), (8, 10), (5, 11), (6, 12), (11, 12), (11, 13), (13, 15), (12, 14), (14, 16)]


@dataclass
class PipelineConfig:
    pose_weights: str = "yolo11m-pose.pt"
    device: str = "0"
    analysis_hz: float = 12.5
    imgsz: int = 1280
    coarse_imgsz: int = 640         # full-frame pass fused with tiles; 0 disables
    det_conf: float = 0.1
    zone_margin_px: float = 80.0    # foot point tolerance at zone edges
    zone_hold_s: float = 2.0        # a track stays in its zone this long after last being inside
    tile_w: int = 1920
    tile_h: int = 1520
    tile_overlap: int = 256
    track_buffer_s: float = 3.0
    track_high: float = 0.5
    track_new: float = 0.6
    hw_decode: bool = False
    write_tracks_csv: bool = True
    preview_video_width: int = 0    # 0 = no annotated video; e.g. 1600 for a light review copy
    alert: AlertPolicyConfig = field(default_factory=AlertPolicyConfig)
    fixture: FixtureConfig = field(default_factory=FixtureConfig)


def _sha256_file(path: str) -> Optional[str]:
    import hashlib
    p = Path(path)
    if not p.is_file():
        return None
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while block := f.read(1 << 20):
            h.update(block)
    return h.hexdigest()


class LegacyScorer:
    """Adapter for src.behavior_classifier.BehaviorTracker (9-keypoint RF)."""

    name = "legacy_rf_pose_temporal_v1"

    def __init__(self, model_path: Path):
        from src.behavior_classifier import BehaviorTracker
        self.tracker = BehaviorTracker(model_path)

    def reset(self):
        self.tracker.reset()

    def __call__(self, track_id: int, t: float, bbox: np.ndarray, kp17: np.ndarray):
        self.tracker.prune(t)
        r = self.tracker.update(track_id, t, tuple(bbox), {"xy": kp17[:, :2], "conf": kp17[:, 2]})
        return r.get("shoplifting_score"), r.get("behavior_status")


def _draw(image, tracks, zones: Optional[CameraZones], width: int, monitor=None):
    scale = width / image.shape[1]
    out = cv2.resize(image, (width, int(round(image.shape[0] * scale))), interpolation=cv2.INTER_AREA)
    if zones:
        for z in zones.zones:
            cv2.polylines(out, [np.round(z.polygon * scale).astype(np.int32)], True, (255, 255, 0), 1)
    for f in (monitor.items or []) if monitor else []:
        color = {"free": (255, 0, 255), "occupied": (0, 165, 255), "settling": (0, 255, 255)}[f.state]
        p1 = (int(f.x1 * scale), int(f.y1 * scale))
        cv2.rectangle(out, p1, (int(f.x2 * scale), int(f.y2 * scale)), color, 1)
        cv2.putText(out, f"{f.name}:{f.state}", (p1[0], p1[1] + 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    for tr in tracks:
        b = (tr["bbox"] * scale).astype(int)
        s = tr.get("score")
        color = (0, 0, 255) if tr.get("alert") else ((0, 165, 255) if s is not None and s >= 0.5 else (0, 200, 0))
        cv2.rectangle(out, tuple(b[:2]), tuple(b[2:]), color, 2)
        label = f"#{tr['track_id']}" + (f" {s:.2f}" if s is not None else "")
        cv2.putText(out, label, (b[0], max(12, b[1] - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
        kp = tr["keypoints"] * np.array([scale, scale, 1])
        for a, c in SKELETON:
            if kp[a, 2] > 0.3 and kp[c, 2] > 0.3:
                cv2.line(out, tuple(kp[a, :2].astype(int)), tuple(kp[c, :2].astype(int)), (255, 255, 0), 1)
    return out


class Pipeline:
    def __init__(self, cfg: PipelineConfig, scorer=None, zones: Optional[CameraZones] = None,
                 notifier=None, fixtures: Optional[CameraZones] = None):
        self.cfg = cfg
        self.fixtures = fixtures
        self.pose = TiledPose(cfg.pose_weights, cfg.imgsz, cfg.det_conf, device=cfg.device,
                              tile_w=cfg.tile_w, tile_h=cfg.tile_h, overlap=cfg.tile_overlap,
                              coarse_imgsz=cfg.coarse_imgsz)
        self.scorer = scorer
        self.base_zones = zones
        self.notifier = notifier

    def run(self, source: str, out_dir: Path, run_name: Optional[str] = None,
            stop: Optional[Callable[[], bool]] = None, max_seconds: Optional[float] = None,
            meta: Optional[Dict] = None) -> Dict:
        cfg = self.cfg
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        live = is_stream(source)
        name = run_name or ("live_" + time.strftime("%Y%m%d_%H%M%S") if live else Path(source).stem)
        tracker = PersonTracker(cfg.analysis_hz, cfg.track_buffer_s, cfg.track_high, new_track=cfg.track_new)
        policy = AlertPolicy(cfg.alert)
        sampler = CadenceSampler(cfg.analysis_hz)
        if self.scorer:
            self.scorer.reset()
        if self.notifier:
            self.notifier.begin_source(name, is_stream=live)

        csv_file = writer = video = None
        if cfg.write_tracks_csv:
            csv_file = open(out_dir / f"{name}_tracks.csv", "w", newline="", encoding="utf-8")
            writer = csv.writer(csv_file)
            writer.writerow(["timestamp_s", "frame", "track_id", "zone", "x1", "y1", "x2", "y2", "conf",
                             *[f"{k}_{a}" for k in COCO17 for a in ("x", "y", "c")], "score", "status"])
        alerts_path = out_dir / f"{name}_alerts.jsonl"
        alerts_f = open(alerts_path, "w", encoding="utf-8")
        monitor = FixtureMonitor(self.fixtures, cfg.fixture, out_dir, name) if self.fixtures else None

        src = open_source(source, cfg.hw_decode)
        duration_s = 0.0
        if not live:
            cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
            if cap.isOpened():
                fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
                count = float(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0.0)
                duration_s = count / fps if fps > 0 else 0.0
            cap.release()
        zones = None
        decoded = analysed = 0
        first_t = last_t = None
        wall0 = time.perf_counter()
        infer_s = 0.0
        track_frames: Dict[int, int] = {}
        zone_state: Dict[int, tuple] = {}  # track_id -> (zone name, last time inside)
        try:
            for frame in src:
                decoded += 1
                if stop and stop():
                    break
                if max_seconds is not None and first_t is not None and frame.timestamp_s - first_t > max_seconds:
                    break
                if not sampler.admit(frame.timestamp_s):
                    continue
                img, t = frame.image, frame.timestamp_s
                h, w = img.shape[:2]
                if zones is None and self.base_zones is not None:
                    zones = self.base_zones.for_frame(w, h)
                first_t = t if first_t is None else first_t
                last_t = t
                regions = [z.bounds() for z in zones.zones] if zones and zones.zones else None

                t_inf = time.perf_counter()
                det = self.pose(img, regions)
                infer_s += time.perf_counter() - t_inf
                # Zones are applied to tracks, not detections: dropping boxes before
                # the tracker breaks identities of people standing on a zone edge.
                all_tracks = tracker.update(det)
                analysed += 1
                tracks = []
                for tr in all_tracks:
                    b = tr["bbox"]
                    foot = ((b[0] + b[2]) / 2, b[3])
                    z = zones.zone_of(*foot, margin_px=cfg.zone_margin_px) if zones else "frame"
                    if z is not None:
                        zone_state[tr["track_id"]] = (z, t)
                    held = zone_state.get(tr["track_id"])
                    if held is not None and t - held[1] <= cfg.zone_hold_s:
                        tr["zone"] = held[0]
                        tracks.append(tr)
                for tid in [k for k, (_, last) in zone_state.items() if t - last > cfg.track_buffer_s + cfg.zone_hold_s]:
                    del zone_state[tid]

                for tr in tracks:
                    tid, b = tr["track_id"], tr["bbox"]
                    track_frames[tid] = track_frames.get(tid, 0) + 1
                    foot = np.array([(b[0] + b[2]) / 2, b[3]])
                    score, status = (self.scorer(tid, t, b, tr["keypoints"]) if self.scorer else (None, "no_scorer"))
                    tr["score"], tr["status"] = score, status
                    alert = policy.update(tid, t, score, foot)
                    tr["alert"] = alert is not None
                    if alert:
                        alert.update(source=name, zone=tr["zone"], bbox=[float(v) for v in b],
                                     frame=frame.index, scorer=getattr(self.scorer, "name", None))
                        alerts_f.write(json.dumps(alert) + "\n")
                        alerts_f.flush()
                        print(f"[Alert] t={t:.1f}s track={tid} median={alert['median_score']:.2f}")
                        if self.notifier:
                            self.notifier.notify_shoplifting(track_id=tid, confidence=alert["median_score"],
                                                             video_position_s=t)
                    if writer:
                        writer.writerow([f"{t:.3f}", frame.index, tid, tr["zone"], *[f"{v:.1f}" for v in b],
                                         f"{tr['conf']:.3f}",
                                         *[f"{v:.4f}" if i % 3 == 2 else f"{v:.1f}"
                                           for i, v in enumerate(tr["keypoints"].ravel())],
                                         "" if score is None else f"{score:.4f}", status])
                policy.forget(t)

                if monitor is not None:
                    # Every tracked person can block a fixture, inside a zone or not.
                    for ev in monitor.update(t, img, all_tracks):
                        print(f"[Fixture] {ev['fixture']} {ev['t_arrive']:.1f}-{ev['t_leave']:.1f}s "
                              f"changed={ev['changed_frac']:.3%} candidate={ev['candidate']}")
                        if ev["candidate"] and cfg.fixture.candidate_to_alerts:
                            main = ev["visitors"][0]
                            alerts_f.write(json.dumps({
                                "kind": "fixture_change", "t": t, "track_id": main["track_id"],
                                "fixture": ev["fixture"], "changed_frac": ev["changed_frac"],
                                "dwell_s": main["dwell_s"], "back_facing_frac": main["back_facing_frac"],
                                "t_arrive": ev["t_arrive"], "t_leave": ev["t_leave"], "bbox": main["bbox"],
                                "source": name, "frame": frame.index, "image": ev["image"]}) + "\n")
                            alerts_f.flush()
                            if self.notifier and cfg.fixture.candidate_to_nx:
                                self.notifier.notify_shoplifting(track_id=main["track_id"],
                                                                 confidence=ev["changed_frac"], video_position_s=t)

                if cfg.preview_video_width:
                    vis = _draw(img, tracks, zones, cfg.preview_video_width, monitor)
                    if video is None:
                        video = cv2.VideoWriter(str(out_dir / f"{name}_review.mp4"),
                                                cv2.VideoWriter_fourcc(*"mp4v"), cfg.analysis_hz,
                                                (vis.shape[1], vis.shape[0]))
                    video.write(vis)
                if analysed % 10 == 0:
                    wall = time.perf_counter() - wall0
                    percent = min(100.0, 100.0 * t / duration_s) if duration_s > 0 else 0.0
                    print(f"[Progress] {percent:5.1f}% ({t:.1f}/{duration_s:.1f}s) "
                          f"analysed={analysed} eff={analysed / max(wall, 1e-6):.1f}Hz "
                          f"infer={1000 * infer_s / analysed:.0f}ms tracks={len(tracks)}")
        finally:
            src.close()
            alerts_f.close()
            if csv_file:
                csv_file.close()
            if video is not None:
                video.release()

        wall = time.perf_counter() - wall0
        lengths = np.array(list(track_frames.values()) or [0])
        span = (last_t - first_t) if first_t is not None else 0.0
        summary = {
            "source": name, "live": live, "config": asdict(cfg), "video": meta or {},
            "pose_weights_sha256": _sha256_file(cfg.pose_weights),
            "scorer": getattr(self.scorer, "name", None),
            "tiles": [asdict(t) for t in self.pose.tiles],
            "decoded_frames": decoded, "analysed_frames": analysed,
            "source_span_s": span, "wall_s": wall,
            "target_hz": cfg.analysis_hz,
            "achieved_hz_vs_source_time": analysed / span if span > 0 else None,
            "processing_speed_x_realtime": span / wall if wall > 0 else None,
            "mean_inference_ms": 1000 * infer_s / max(analysed, 1),
            "track_ids": len(track_frames),
            "track_len_median_s": float(np.median(lengths) / cfg.analysis_hz),
            "alerts": sum(1 for _ in open(alerts_path, encoding="utf-8")),
            "fixture_events": len(monitor.events) if monitor else None,
            "fixture_candidates": sum(e["candidate"] for e in monitor.events) if monitor else None,
        }
        if isinstance(src, LiveSource):
            summary.update(live_decoded=src.decoded, live_dropped=src.dropped, reconnects=src.reconnects)
        (out_dir / f"{name}_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return summary
