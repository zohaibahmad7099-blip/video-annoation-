"""Tracker-independent behaviour labels for the Stage A classifier.

One JSON file per video (`labels/<video_key>.json`). Labels belong to *persons*:
a reviewed box trajectory (snapshot of linked reference-track fragments), so the
dataset builder can map them onto any extraction (YOLO11 or YOLO26, any run) by
time and box overlap. See docs/LABELLING_GUIDE.md for the rules.

Each person carries two piecewise-constant timelines over their visible time:
`phase` (what the hands do with merchandise) and `visibility` (what the camera
can see). Training targets are derived here, never typed by hand.
"""
import json
import os
import tempfile
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

SCHEMA = "shoplift-labels/1"
PHASES = ("normal", "inspect", "pick", "suspicious", "basket", "return", "unknown")
VISIBILITY = ("visible", "hands_occluded", "body_occluded")
GUARD_S = 0.3                            # excluded margin at each edge of a positive interval
MAX_GAP_S = 0.3                          # coverage gap tolerated inside a person's span


@dataclass
class Segment:
    start_s: float
    end_s: float
    value: str
    event_id: str = ""


@dataclass
class Person:
    person_id: str
    track_ids: List[int] = field(default_factory=list)
    boxes: List[List[float]] = field(default_factory=list)   # [t, x1, y1, x2, y2] at reference cadence
    actor_id: str = ""
    is_staff: bool = False
    phase: List[Segment] = field(default_factory=list)
    visibility: List[Segment] = field(default_factory=list)
    note: str = ""

    @property
    def span(self) -> Optional[Tuple[float, float]]:
        return (self.boxes[0][0], self.boxes[-1][0]) if self.boxes else None


@dataclass
class MissedEvent:
    """A concealment with no usable track (missed detection); counts against recall."""
    event_id: str
    start_s: float
    end_s: float
    box: Optional[List[float]] = None
    note: str = ""


@dataclass
class VideoLabels:
    video_key: str
    video_name: str
    sha256: str
    reference_tracks: str = ""          # tracks CSV the track_ids refer to (repo-relative)
    reference_tracks_sha256: str = ""
    persons: List[Person] = field(default_factory=list)
    missed_events: List[MissedEvent] = field(default_factory=list)
    complete: bool = False              # every person and event in the video reviewed
    reviewer: str = ""
    updated: str = ""
    schema: str = SCHEMA

    def person(self, person_id: str) -> Person:
        return next(p for p in self.persons if p.person_id == person_id)

    def person_of_track(self, track_id: int) -> Optional[Person]:
        return next((p for p in self.persons if track_id in p.track_ids), None)

    def next_person_id(self) -> str:
        used = {p.person_id for p in self.persons}
        return next(f"p{i}" for i in range(1, 10_000) if f"p{i}" not in used)

    def event_ids(self) -> List[str]:
        ids = {s.event_id for p in self.persons for s in p.phase if s.event_id}
        ids |= {m.event_id for m in self.missed_events}
        return sorted(ids, key=lambda e: (len(e), e))

    def next_event_id(self) -> str:
        used = set(self.event_ids())
        return next(f"ev{i}" for i in range(1, 10_000) if f"ev{i}" not in used)


# ---------------------------------------------------------------- timelines
def paint(segments: List[Segment], start: float, end: float, value: str, event_id: str = "") -> List[Segment]:
    """Overwrite [start, end) with value; keeps segments sorted, non-overlapping, merged."""
    if end <= start:
        raise ValueError("end must be after start")
    out: List[Segment] = []
    for s in segments:
        if s.end_s <= start or s.start_s >= end:
            out.append(s)
            continue
        if s.start_s < start:
            out.append(Segment(s.start_s, start, s.value, s.event_id))
        if s.end_s > end:
            out.append(Segment(end, s.end_s, s.value, s.event_id))
    out.append(Segment(start, end, value, event_id))
    out.sort(key=lambda s: s.start_s)
    merged: List[Segment] = []
    for s in out:
        if merged and merged[-1].value == s.value and merged[-1].event_id == s.event_id \
                and abs(merged[-1].end_s - s.start_s) < 1e-6:
            merged[-1].end_s = s.end_s
        else:
            merged.append(s)
    return merged


def value_at(segments: List[Segment], t: float) -> Optional[Segment]:
    for s in segments:
        if s.start_s <= t < s.end_s:
            return s
    return None


# ---------------------------------------------------------------- targets
@dataclass
class StepTargets:
    suspicious: np.ndarray       # float 0/1
    suspicious_mask: np.ndarray  # bool: contributes to the suspicious loss
    visibility: np.ndarray       # int index into VISIBILITY, -1 unlabelled
    phase: np.ndarray            # int index into PHASES (unknown -> -1)
    event_id: np.ndarray         # str, "" if none


def targets(person: Person, times: np.ndarray, guard_s: float = GUARD_S) -> StepTargets:
    """Per-step targets for one person at the given times (label at each step's endpoint).

    suspicious = shoplifting while visible. Hidden hands/body remain masked because
    the behavior is not observable from pose alone.
    """
    n = len(times)
    susp = np.zeros(n, np.float32)
    mask = np.ones(n, bool)
    vis = np.full(n, -1, np.int64)
    ph = np.full(n, -1, np.int64)
    ev = np.array([""] * n, dtype=object)
    for i, t in enumerate(times):
        p = value_at(person.phase, t)
        v = value_at(person.visibility, t)
        vis[i] = VISIBILITY.index(v.value) if v else -1
        if p is None:
            mask[i] = False
            continue
        ph[i] = PHASES.index(p.value)
        ev[i] = p.event_id
        if p.value == "suspicious":
            if v is None or v.value != "visible":
                mask[i] = False
            else:
                susp[i] = 1.0
    for s in person.phase:
        if s.value != "suspicious":
            continue
        for edge in (s.start_s, s.end_s):
            mask &= ~((times >= edge - guard_s) & (times < edge + guard_s))
    return StepTargets(susp, mask, vis, ph, ev)


# ---------------------------------------------------------------- validation
def lint(v: VideoLabels) -> Tuple[List[str], List[str]]:
    """(errors, warnings). Errors block `complete` and dataset building."""
    errors, warnings = [], []
    if v.schema != SCHEMA:
        errors.append(f"schema {v.schema!r} != {SCHEMA!r}")
    seen_tracks: Dict[int, str] = {}
    event_conceal: Dict[str, List[str]] = {}
    event_any: Dict[str, List[str]] = {}
    for p in v.persons:
        tag = f"{p.person_id}"
        if not p.boxes:
            errors.append(f"{tag}: no box trajectory (link at least one track)")
            continue
        for tid in p.track_ids:
            if tid in seen_tracks:
                errors.append(f"track {tid} linked to both {seen_tracks[tid]} and {p.person_id}")
            seen_tracks[tid] = p.person_id
        t0, t1 = p.span
        for name, segs, allowed in (("phase", p.phase, PHASES), ("visibility", p.visibility, VISIBILITY)):
            for a, b in zip(segs, segs[1:]):
                if b.start_s < a.end_s - 1e-6:
                    errors.append(f"{tag}: overlapping {name} segments at {b.start_s:.2f}s")
            for s in segs:
                if s.value not in allowed:
                    errors.append(f"{tag}: invalid {name} {s.value!r}")
                if s.start_s < t0 - 0.2 or s.end_s > t1 + 0.2:
                    warnings.append(f"{tag}: {name} {s.start_s:.2f}-{s.end_s:.2f}s outside person span {t0:.2f}-{t1:.2f}s")
            covered = sorted((max(s.start_s, t0), min(s.end_s, t1)) for s in segs)
            gaps, cursor = [], t0
            for a, b in covered:
                if a - cursor > MAX_GAP_S:
                    gaps.append((cursor, a))
                cursor = max(cursor, b)
            if t1 - cursor > MAX_GAP_S:
                gaps.append((cursor, t1))
            if gaps:
                msg = f"{tag}: {name} not labelled for " + ", ".join(f"{a:.1f}-{b:.1f}s" for a, b in gaps)
                (errors if v.complete else warnings).append(msg)
        for s in p.phase:
            if s.event_id:
                event_any.setdefault(s.event_id, []).append(p.person_id)
                if s.value == "suspicious":
                    event_conceal.setdefault(s.event_id, []).append(p.person_id)
        involved = any(s.event_id for s in p.phase)
        if involved and not p.actor_id:
            errors.append(f"{tag}: involved in an event but has no actor_id (needed for leakage-free splits)")
        elif not p.actor_id:
            warnings.append(f"{tag}: no actor_id")
    missed = {m.event_id for m in v.missed_events}
    for e, who in event_any.items():
        if e not in event_conceal and e not in missed:
            errors.append(f"event {e}: has a pick but no conceal (a purchase pick must not carry an event_id)")
        if len(set(who)) > 1:
            warnings.append(f"event {e}: spans persons {sorted(set(who))} (accomplices? check)")
    for m in v.missed_events:
        if m.end_s <= m.start_s:
            errors.append(f"missed event {m.event_id}: end before start")
    return errors, warnings


# ---------------------------------------------------------------- IO
def _from_dict(d: Dict) -> VideoLabels:
    persons = [Person(**{**p, "phase": [Segment(**s) for s in p.get("phase", [])],
                         "visibility": [Segment(**s) for s in p.get("visibility", [])]})
               for p in d.get("persons", [])]
    missed = [MissedEvent(**m) for m in d.get("missed_events", [])]
    return VideoLabels(**{**d, "persons": persons, "missed_events": missed})


def load(path: Path) -> VideoLabels:
    return _from_dict(json.loads(Path(path).read_text(encoding="utf-8")))


def index_label_files(labels_dir: Path) -> Dict[str, Path]:
    """Return label JSON files indexed by their embedded video key."""
    indexed: Dict[str, Path] = {}
    for path in sorted(Path(labels_dir).glob("*.json")):
        if path.name == "videos.json" or path.name.startswith("~$"):
            continue
        labels = load(path)
        if labels.video_key in indexed:
            existing = load(indexed[labels.video_key])
            if existing.sha256 != labels.sha256:
                raise ValueError(f"duplicate label files for video_key {labels.video_key!r}: "
                                 f"{indexed[labels.video_key].name} and {path.name}")
            if path.stem == labels.video_name and indexed[labels.video_key].stem != labels.video_name:
                indexed[labels.video_key] = path
            continue
        indexed[labels.video_key] = path
    return indexed


def save(v: VideoLabels, path: Path) -> None:
    """Atomic write so a crash never leaves a half-written label file."""
    v.updated = datetime.now(timezone.utc).isoformat(timespec="seconds")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(asdict(v), f, indent=1)
    os.replace(tmp, path)
