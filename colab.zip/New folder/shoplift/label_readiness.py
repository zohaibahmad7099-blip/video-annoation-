"""Readiness: would the training pipeline accept a label file exactly as it is?

A video is READY when `shoplift.dataset_build` would use it without skipping it
or stopping, and the labelling-guide rules that `annotation.lint` does not
enforce also hold:

  * the video is in labels/videos.json with the same content hash
  * the labels are marked complete and lint reports no errors *as complete*
    (lint only turns unlabelled time into an error once `complete` is set, so
    the check runs on a trial copy with complete=True)
  * every `suspicious` segment belongs to an event; only pick/suspicious carry events
  * a reviewer is named
  * a session_id is set (dataset_build refuses non-holdout videos without one)

Warnings never block; they are what a second reviewer would look at.
Dataset-level checks (actor ids, split groups, stray files) are in check_dataset.

  python -m shoplift.label_readiness            # print the report for this folder
"""
import argparse
import copy
import hashlib
import json
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from shoplift.annotation import VideoLabels, _from_dict, lint
from shoplift.registry import VideoEntry, load_registry

READY, NOT_READY, IN_PROGRESS, NOT_STARTED = "READY", "NOT READY", "IN PROGRESS", "NOT STARTED"
REFERENCE_SOURCE = "yolo11m_10hz"
PLACEHOLDER_REVIEWERS = {"", "yourname", "your name", "<your name>", "name"}
FOLDS = 5


@dataclass
class Workspace:
    """Folder layout shared by annotate.py, the studio and the training pipeline."""
    root: Path

    def __post_init__(self):
        self.root = Path(self.root).resolve()

    @property
    def labels_dir(self) -> Path:
        return self.root / "labels"

    @property
    def registry_path(self) -> Path:
        return self.labels_dir / "videos.json"

    @property
    def tracks_dir(self) -> Path:
        return self.root / "outputs" / "extract" / REFERENCE_SOURCE

    @property
    def exports_dir(self) -> Path:
        return self.root / "exports"

    def tracks_csv(self, name: str) -> Path:
        return self.tracks_dir / f"{name}_tracks.csv"

    def summary_json(self, name: str) -> Path:
        return self.tracks_dir / f"{name}_summary.json"

    def label_path(self, name: str) -> Path:
        return self.labels_dir / f"{name}.json"

    def video_file(self, entry: VideoEntry) -> Optional[Path]:
        for p in entry.paths:
            path = Path(p) if Path(p).is_absolute() else self.root / p
            if path.is_file():
                return path
        return None

    def rel(self, path: Path) -> str:
        path = Path(path).resolve()
        return str(path.relative_to(self.root)) if path.is_relative_to(self.root) else str(path)


@dataclass
class VideoReport:
    key: str
    name: str
    status: str
    entry: Optional[VideoEntry] = None
    label_path: Optional[Path] = None
    labels: Optional[VideoLabels] = None
    complete: bool = False
    persons: int = 0
    events: int = 0
    reviewer: str = ""
    updated: str = ""
    content_sha: str = ""
    blocking: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def ready(self) -> bool:
        return self.status == READY


@dataclass
class DatasetReport:
    videos: List[VideoReport]
    warnings: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    roster: Dict[str, List[Tuple[str, str, bool, Optional[list]]]] = field(default_factory=dict)
    groups: int = 0

    @property
    def ready(self) -> List[VideoReport]:
        return [v for v in self.videos if v.ready]

    def get(self, key: str) -> Optional[VideoReport]:
        return next((v for v in self.videos if v.key == key), None)


# ---------------------------------------------------------------- helpers
def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while block := f.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def content_sha(data) -> str:
    """Hash of a label file's content ignoring the `updated` timestamp, so
    opening and re-saving a file without edits does not make it 'changed'."""
    if isinstance(data, (str, Path)):
        data = json.loads(Path(data).read_text(encoding="utf-8"))
    d = {k: v for k, v in data.items() if k != "updated"}
    return hashlib.sha256(json.dumps(d, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def load_labels(path: Path) -> VideoLabels:
    L = _from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
    migrate_legacy_phases(L)
    return L


def migrate_legacy_phases(L: VideoLabels) -> None:
    """Same conversion annotate.py applies to files from the earlier schema."""
    for p in L.persons:
        for s in p.phase:
            if s.value == "none":
                s.value = "normal"
            elif s.value in {"conceal", "shoplifting"}:
                s.value = "suspicious"


def scan_label_files(labels_dir: Path):
    """Label files by embedded video_key, tolerant of junk and duplicates.

    Returns (by_key, problems, junk). The canonical file (<video_key>.json) wins
    over other files that carry the same key.
    """
    by_key: Dict[str, Path] = {}
    problems: List[str] = []
    junk: List[Path] = []
    for path in sorted(Path(labels_dir).glob("*.json")):
        if path.name == "videos.json":
            continue
        if path.name.startswith("~$"):
            junk.append(path)
            continue
        try:
            key = json.loads(path.read_text(encoding="utf-8"))["video_key"]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            problems.append(f"{path.name}: not a readable label file ({exc.__class__.__name__}) - ignored")
            continue
        if key in by_key:
            keep, other = (path, by_key[key]) if path.stem == key else (by_key[key], path)
            problems.append(f"{other.name} and {keep.name} both hold labels for '{key}'; "
                            f"{keep.name} is used - delete or rename the other one")
            by_key[key] = keep
        else:
            by_key[key] = path
    return by_key, problems, junk


def guide_errors(L: VideoLabels) -> List[str]:
    """Guide rules (section 6) that annotation.lint does not check."""
    errs = []
    for p in L.persons:
        for s in p.phase:
            if s.value == "suspicious" and not s.event_id:
                errs.append(f"{p.person_id}: suspicious {s.start_s:.2f}-{s.end_s:.2f}s has no event "
                            f"(every concealment must belong to an event)")
            if s.event_id and s.value not in ("pick", "suspicious"):
                errs.append(f"{p.person_id}: {s.value} {s.start_s:.2f}-{s.end_s:.2f}s carries event "
                            f"{s.event_id} (only pick and suspicious may carry an event)")
    return errs


def completion_check(L: VideoLabels) -> Tuple[List[str], List[str]]:
    """(errors, warnings) as if the video were marked complete."""
    trial = copy.copy(L)
    trial.complete = True
    errs, warns = lint(trial)
    return errs + guide_errors(L), warns


def picks_without_event(L: VideoLabels) -> int:
    return sum(1 for p in L.persons for s in p.phase
               if s.value == "pick" and not s.event_id and any(x.value == "suspicious" for x in p.phase))


# ---------------------------------------------------------------- per video
def check_video(ws: Workspace, key: str, entry: Optional[VideoEntry], label_path: Optional[Path],
                labels: Optional[VideoLabels] = None) -> VideoReport:
    name = entry.name if entry else key
    r = VideoReport(key, name, NOT_STARTED, entry, label_path)
    if label_path is None and labels is None:
        r.blocking.append("not labelled yet")
        return r
    try:
        L = labels if labels is not None else load_labels(label_path)
        r.content_sha = content_sha(json.loads(label_path.read_text(encoding="utf-8"))) if label_path else ""
    except Exception as exc:  # noqa: BLE001 - any unreadable file is a blocking problem
        r.status = NOT_READY
        r.blocking.append(f"label file cannot be read: {exc}")
        return r
    r.labels = L
    r.complete, r.persons, r.reviewer, r.updated = L.complete, len(L.persons), L.reviewer, L.updated
    r.events = len(L.event_ids())

    if entry is None:
        r.blocking.append(f"video '{key}' is not in labels/videos.json - register the video file "
                          f"(Check tab > Register video) so the training pipeline can find it")
    elif entry.sha256 != L.sha256:
        r.blocking.append("labels were made for different video content than the registered file (hash differs)")
    if not L.complete:
        r.blocking.append("not marked complete (Label tab > Mark complete when every person is labelled)")
    errs, warns = completion_check(L)
    r.blocking += errs
    if L.reviewer.strip().lower() in PLACEHOLDER_REVIEWERS:
        r.blocking.append("reviewer not set (enter your name in the Label tab)")
    if entry is not None and not entry.holdout and not entry.session_id.strip():
        r.blocking.append("session_id not set - the training build stops without it "
                          "(Label tab > Session, e.g. S1 for all clips of one recording day)")

    r.warnings += warns
    if (n := picks_without_event(L)):
        r.warnings.append(f"{n} pick(s) by a person who later conceals have no event - if a picked item is "
                          f"the stolen one, relabel that pick with key 4")
    if L.complete and not L.persons:
        r.warnings.append("marked complete with no persons - only correct if nobody appears in the video")
    ref = ws.root / L.reference_tracks.replace("\\", "/") if L.reference_tracks else ws.tracks_csv(name)
    if not ref.is_file():
        r.warnings.append("reference tracks CSV is not on this machine - the export will not include it")
    elif L.reference_tracks_sha256 and file_sha256(ref) != L.reference_tracks_sha256:
        r.warnings.append("reference tracks changed since labelling - open the video and press "
                          "'Re-link tracks' (person boxes are kept)")
    if label_path is not None and label_path.stem != key:
        r.notes.append(f"file is named {label_path.name}; exported as {key}.json")
    if entry is not None and entry.holdout:
        r.notes.append("HOLDOUT video: used only for the final test, never for training")

    if not r.blocking:
        r.status = READY
    elif L.complete:
        r.status = NOT_READY
    else:
        r.status = IN_PROGRESS
    return r


# ---------------------------------------------------------------- dataset
def _split_groups(reports: List[VideoReport]) -> int:
    parent: Dict[str, str] = {}

    def root(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    keys = []
    for r in reports:
        if r.entry is None or r.entry.holdout or r.labels is None:
            continue
        s = f"session:{r.entry.session_id or 'video:' + r.key}"
        keys.append(s)
        root(s)
        for p in r.labels.persons:
            if p.actor_id:
                parent[root(s)] = root(f"actor:{p.actor_id}")
    return len({root(k) for k in keys})


def check_dataset(ws: Workspace) -> DatasetReport:
    reg = load_registry(ws.registry_path)
    by_key, problems, junk = scan_label_files(ws.labels_dir)
    reports = [check_video(ws, k, reg.get(k), by_key.get(k)) for k in sorted(set(reg) | set(by_key), key=str.lower)]
    rep = DatasetReport(reports)
    rep.warnings += problems
    for j in junk:
        rep.notes.append(f"{j.name}: lock/temporary file left by another program (a label file was opened in "
                         f"an editor) - safe to delete; never edit label files by hand")

    roster: Dict[str, list] = defaultdict(list)
    placeholder_videos = with_actors = 0
    for r in reports:
        L = r.labels
        if L is None:
            continue
        actors = [(p.person_id, p.actor_id) for p in L.persons if p.actor_id]
        if actors:
            with_actors += 1
            if all(re.fullmatch(r"p(\d+)", pid) and a == f"A{pid[1:]}" for pid, a in actors):
                placeholder_videos += 1
        for p in L.persons:
            if p.actor_id:
                mid = p.boxes[len(p.boxes) // 2] if p.boxes else None
                roster[p.actor_id].append((r.name, p.person_id, bool(p.is_staff), mid))
    rep.roster = dict(roster)
    if with_actors >= 3 and placeholder_videos >= 0.8 * with_actors:
        rep.warnings.append(
            f"actor_id equals the person number in {placeholder_videos} of {with_actors} labelled videos "
            f"(p1=A1, p2=A2, ...). "
            "actor_id must name the same real individual in every video; numbering by person order links "
            "unrelated people and merges every session into one split group. Check with 'Actor gallery'.")
    for a, who in sorted(roster.items()):
        staff = {s for _, _, s, _ in who}
        if len(staff) > 1:
            vids = sorted({v for v, _, s, _ in who if s})
            rep.warnings.append(f"actor {a} is staff in {vids} but a shopper elsewhere - same individual?")
    rep.groups = _split_groups(reports)
    labelled = sum(1 for r in reports if r.labels is not None and r.entry is not None and not r.entry.holdout)
    if labelled and rep.groups < FOLDS:
        rep.warnings.append(
            f"only {rep.groups} independent split group(s) from {labelled} labelled videos (sessions joined by "
            f"shared actor ids); a {FOLDS}-fold training split needs at least {FOLDS}")
    return rep


def format_report(rep: DatasetReport) -> str:
    out = []
    for r in rep.videos:
        out.append(f"\n{r.name} [{r.label_path.name if r.label_path else '-'}] {r.status}  "
                   f"persons={r.persons} events={r.events} reviewer={r.reviewer!r}")
        out += [f"  BLOCK {x}" for x in r.blocking if r.status != NOT_STARTED]
        out += [f"  WARN  {x}" for x in r.warnings]
        out += [f"  NOTE  {x}" for x in r.notes]
    out.append("\nDataset:")
    out += [f"  WARN  {x}" for x in rep.warnings]
    out += [f"  NOTE  {x}" for x in rep.notes]
    out.append(f"  split groups: {rep.groups}; actors: {', '.join(sorted(rep.roster, key=lambda a: (len(a), a)))}")
    n_ready = len(rep.ready)
    started = sum(1 for r in rep.videos if r.status != NOT_STARTED)
    out.append(f"\n{n_ready} of {started} labelled videos READY")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    a = ap.parse_args()
    rep = check_dataset(Workspace(a.root))
    print(format_report(rep))
    blocking = [r for r in rep.videos if r.status in (NOT_READY,)]
    return 1 if blocking else 0


if __name__ == "__main__":
    sys.exit(main())
