"""Hand labels to the training pipeline as one verified zip - no back and forth.

Labeller side (or the Export tab of labelling_studio.py):
  python -m shoplift.label_exchange export --reviewer Zohaib            # every READY video
  python -m shoplift.label_exchange export --videos "2" "159 Back Cooler_9"

Training side, in the training repository root:
  python -m shoplift.label_exchange verify exports/labels_Zohaib_20261106_1200.zip
  python -m shoplift.label_exchange import exports/labels_Zohaib_20261106_1200.zip [--dry-run]

Package layout (paths are relative to the repository root, so it unpacks in place):
  export_manifest.json                          what is inside, with per-file SHA-256
  labels/<video_key>.json                       canonical label files (READY only)
  labels/videos.json                            registry entries of the exported videos
  outputs/extract/yolo11m_10hz/<name>_tracks.csv, _summary.json   reference tracks

Import re-runs the same readiness checks, never overwrites a label file without
a backup, keeps the training side's video paths, holdout flags and tracks, and
only fills in session ids that are empty there.
"""
import argparse
import getpass
import json
import platform
import re
import shutil
import sys
import zipfile
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from shoplift.annotation import SCHEMA, _from_dict
from shoplift.label_readiness import (REFERENCE_SOURCE, Workspace, check_dataset, completion_check, content_sha,
                                      migrate_legacy_phases)
from shoplift.registry import VideoEntry, load_registry, save_registry

FORMAT = "shoplift-label-export/1"
LOG_NAME = "export_log.json"
_SAFE = re.compile(r"^(labels/[^/\\]+\.json|outputs/extract/" + REFERENCE_SOURCE + r"/[^/\\]+\.(csv|json))$")


def _sha(data: bytes) -> str:
    return sha256(data).hexdigest()


def read_log(ws: Workspace) -> List[Dict]:
    p = ws.exports_dir / LOG_NAME
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else []
    except (OSError, ValueError):
        return []


def last_exported(ws: Workspace) -> Dict[str, str]:
    """video_key -> label content hash at its most recent export."""
    out: Dict[str, str] = {}
    for rec in read_log(ws):
        out.update(rec.get("videos", {}))
    return out


# ---------------------------------------------------------------- export
def export_labels(ws: Workspace, keys: Optional[List[str]] = None, out_dir: Optional[Path] = None,
                  include_tracks: bool = True, exporter: str = "") -> Tuple[Path, Dict]:
    rep = check_dataset(ws)
    ready = {r.key: r for r in rep.ready}
    if keys is None:
        keys = sorted(ready)
    not_ready = [k for k in keys if k not in ready]
    if not_ready:
        reasons = []
        for k in not_ready:
            r = rep.get(k)
            reasons.append(f"{k}: " + ("; ".join(r.blocking[:3]) if r else "unknown video"))
        raise ValueError("only READY videos can be exported:\n  " + "\n  ".join(reasons))
    if not keys:
        raise ValueError("no READY videos to export")

    exporter = exporter or next((ready[k].reviewer for k in keys if ready[k].reviewer), "") or getpass.getuser()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path(out_dir or ws.exports_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", exporter).strip("_") or "labeller"
    zpath = out_dir / f"labels_{safe_name}_{stamp}.zip"

    files: Dict[str, bytes] = {}
    videos, registry = {}, {}
    for k in keys:
        r = ready[k]
        data = json.loads(r.label_path.read_text(encoding="utf-8"))
        files[f"labels/{k}.json"] = json.dumps(data, indent=1).encode("utf-8")
        registry[k] = asdict(r.entry)
        included_tracks = []
        if include_tracks:
            for p in (ws.tracks_csv(r.name), ws.summary_json(r.name)):
                if p.is_file():
                    arc = f"outputs/extract/{REFERENCE_SOURCE}/{p.name}"
                    files[arc] = p.read_bytes()
                    included_tracks.append(arc)
        L = r.labels
        videos[k] = {
            "name": r.name, "video_sha256": r.entry.sha256, "label_content_sha256": r.content_sha,
            "session_id": r.entry.session_id, "holdout": r.entry.holdout, "reviewer": L.reviewer,
            "updated": L.updated, "persons": len(L.persons), "events": L.event_ids(),
            "missed_events": len(L.missed_events),
            "actors": sorted({p.actor_id for p in L.persons if p.actor_id}),
            "reference_tracks_sha256": L.reference_tracks_sha256, "tracks_files": included_tracks,
            "warnings": r.warnings,
        }
    files["labels/videos.json"] = json.dumps(registry, indent=1).encode("utf-8")
    manifest = {
        "format": FORMAT, "label_schema": SCHEMA, "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "exporter": exporter, "machine": platform.node(), "videos": videos,
        "dataset_warnings": rep.warnings,
        "files": {name: {"sha256": _sha(b), "bytes": len(b)} for name, b in sorted(files.items())},
    }
    tmp = zpath.with_suffix(".zip.part")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("export_manifest.json", json.dumps(manifest, indent=1))
        for name, b in sorted(files.items()):
            z.writestr(name, b)
    tmp.replace(zpath)
    ok, lines = verify_package(zpath)
    if not ok:
        zpath.unlink(missing_ok=True)
        raise RuntimeError("the package failed its own verification:\n" + "\n".join(lines))

    log = read_log(ws)
    log.append({"file": zpath.name, "path": str(zpath), "created": manifest["created"], "exporter": exporter,
                "videos": {k: v["label_content_sha256"] for k, v in videos.items()}})
    (ws.exports_dir).mkdir(parents=True, exist_ok=True)
    (ws.exports_dir / LOG_NAME).write_text(json.dumps(log, indent=1), encoding="utf-8")
    return zpath, manifest


# ---------------------------------------------------------------- verify
def _open_package(zpath: Path):
    z = zipfile.ZipFile(zpath)
    names = set(z.namelist())
    if "export_manifest.json" not in names:
        raise ValueError("not a label export (export_manifest.json missing)")
    return z, names, json.loads(z.read("export_manifest.json"))


def verify_package(zpath: Path) -> Tuple[bool, List[str]]:
    """Integrity + label checks, needing nothing but the zip itself."""
    lines, ok = [], True
    try:
        z, names, man = _open_package(zpath)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        return False, [f"FAIL cannot read package: {exc}"]
    with z:
        if man.get("format") != FORMAT:
            lines.append(f"FAIL unknown package format {man.get('format')!r}")
            ok = False
        listed = set(man.get("files", {}))
        for name in sorted(names - {"export_manifest.json"} - listed):
            lines.append(f"FAIL unlisted file in package: {name}")
            ok = False
        for name, meta in sorted(man.get("files", {}).items()):
            if not _SAFE.match(name):
                lines.append(f"FAIL unexpected path {name}")
                ok = False
            elif name not in names:
                lines.append(f"FAIL missing file {name}")
                ok = False
            elif _sha(z.read(name)) != meta["sha256"]:
                lines.append(f"FAIL {name} is corrupted (hash differs)")
                ok = False
        try:
            reg_part = json.loads(z.read("labels/videos.json")) if "labels/videos.json" in names else {}
        except ValueError:
            reg_part, ok = {}, False
            lines.append("FAIL labels/videos.json unreadable")
        for key, info in sorted(man.get("videos", {}).items()):
            name = f"labels/{key}.json"
            if name not in names:
                continue
            try:
                d = json.loads(z.read(name))
                L = _from_dict(d)
                migrate_legacy_phases(L)
            except Exception as exc:  # noqa: BLE001
                lines.append(f"FAIL {key}: label file unreadable ({exc})")
                ok = False
                continue
            errs, _ = completion_check(L)
            probs = list(errs)
            if not L.complete:
                probs.append("not marked complete")
            if content_sha(d) != info.get("label_content_sha256"):
                probs.append("content differs from the manifest")
            entry = reg_part.get(key)
            if entry is None:
                probs.append("no registry entry in the package")
            elif entry.get("sha256") != L.sha256:
                probs.append("registry hash differs from the labels")
            elif not entry.get("holdout") and not entry.get("session_id"):
                probs.append("session_id missing")
            if probs:
                ok = False
                lines.append(f"FAIL {key}: " + "; ".join(probs[:5]))
            else:
                lines.append(f"OK   {key}: {len(L.persons)} persons, events {L.event_ids() or '-'}, "
                             f"session {entry.get('session_id') or 'holdout'}, reviewer {L.reviewer}")
        for w in man.get("dataset_warnings", []):
            lines.append(f"WARN {w}")
    lines.append("PACKAGE OK" if ok else "PACKAGE REJECTED")
    return ok, lines


# ---------------------------------------------------------------- import
def import_package(zpath: Path, ws: Workspace, dry_run: bool = False) -> Tuple[bool, List[str]]:
    ok, lines = verify_package(zpath)
    if not ok:
        return False, lines + ["nothing imported"]
    z, names, man = _open_package(zpath)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = ws.labels_dir / "_import_backup" / stamp
    reg = load_registry(ws.registry_path)
    pkg_reg = {k: VideoEntry(**v) for k, v in json.loads(z.read("labels/videos.json")).items()}
    out = [f"importing {zpath.name} from {man.get('exporter')} ({man.get('created')})" + (" [dry run]" if dry_run else "")]
    reg_changed = False
    with z:
        for key, info in sorted(man["videos"].items()):
            e = pkg_reg[key]
            local = next((x for x in reg.values() if x.sha256 == e.sha256), None)
            if local is None and key in reg:
                out.append(f"SKIP {key}: a different video is registered under this name here")
                continue
            if local is None:
                reg[key] = e
                reg_changed = True
                out.append(f"NEW  {key}: registry entry added - its video path is from the labeller's machine "
                           f"({e.paths[0] if e.paths else '-'}); fix paths with register_videos.py")
            else:
                if local.name != key:
                    out.append(f"SKIP {key}: this video is registered here as '{local.name}'")
                    continue
                if e.session_id and not local.session_id:
                    local.session_id = e.session_id
                    reg_changed = True
                    out.append(f"     {key}: session_id set to {e.session_id}")
                elif e.session_id and e.session_id != local.session_id:
                    out.append(f"WARN {key}: package session {e.session_id!r} differs from ours "
                               f"{local.session_id!r} - ours kept")
            data = z.read(f"labels/{key}.json")
            target = ws.label_path(key)
            if target.is_file():
                try:
                    same = content_sha(json.loads(target.read_text(encoding="utf-8"))) == info["label_content_sha256"]
                except (OSError, ValueError):
                    same = False
                if same:
                    out.append(f"SAME {key}: labels unchanged")
                else:
                    out.append(f"UPD  {key}: labels updated (previous file backed up to {ws.rel(backup)})")
                    if not dry_run:
                        backup.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(target, backup / target.name)
                        target.write_bytes(data)
            else:
                out.append(f"ADD  {key}: labels added")
                if not dry_run:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(data)
            for arc in info.get("tracks_files", []):
                dest = ws.root / arc
                blob = z.read(arc)
                if not dest.is_file():
                    out.append(f"     {key}: reference tracks {Path(arc).name} added")
                    if not dry_run:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_bytes(blob)
                elif _sha(dest.read_bytes()) != _sha(blob):
                    out.append(f"WARN {key}: our {Path(arc).name} differs from the labeller's - ours kept "
                               f"(labels map by box overlap, track ids are not needed)")
    if reg_changed and not dry_run:
        save_registry(ws.registry_path, reg)
    if not dry_run:
        rep = check_dataset(ws)
        ready = sum(1 for r in rep.ready if r.key in man["videos"])
        out.append(f"after import: {ready} of {len(man['videos'])} imported videos READY in this repository")
        log = ws.labels_dir / "import_log.jsonl"
        with open(log, "a", encoding="utf-8") as f:
            f.write(json.dumps({"package": zpath.name, "imported": stamp, "exporter": man.get("exporter"),
                                "videos": man["videos"] and sorted(man["videos"]), "lines": out}) + "\n")
    return True, lines + out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    sub = ap.add_subparsers(dest="cmd", required=True)
    ex = sub.add_parser("export")
    ex.add_argument("--videos", nargs="+")
    ex.add_argument("--reviewer", default="")
    ex.add_argument("--out", type=Path)
    ex.add_argument("--no-tracks", action="store_true")
    for name in ("verify", "import"):
        p = sub.add_parser(name)
        p.add_argument("package", type=Path)
        if name == "import":
            p.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    ws = Workspace(a.root)
    if a.cmd == "export":
        try:
            path, man = export_labels(ws, a.videos, a.out, not a.no_tracks, a.reviewer)
        except ValueError as exc:
            sys.exit(str(exc))
        print(f"Exported {len(man['videos'])} video(s) to {path}")
        return 0
    if a.cmd == "verify":
        ok, lines = verify_package(a.package)
    else:
        ok, lines = import_package(a.package, ws, a.dry_run)
    print("\n".join(lines))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
