"""Analysis zones stored per camera and resolution.

Zones only decide which detections are analysed (by foot point) and which part
of the frame is tiled. Pixels are never blacked out.
"""
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np


@dataclass
class Zone:
    name: str
    polygon: np.ndarray  # (N, 2) float, full-frame pixels

    def contains(self, x: float, y: float) -> bool:
        # Ray casting; avoids a cv2 dependency here.
        p = self.polygon
        inside = False
        j = len(p) - 1
        for i in range(len(p)):
            xi, yi = p[i]
            xj, yj = p[j]
            if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi:
                inside = not inside
            j = i
        return inside

    def distance_outside(self, x: float, y: float) -> float:
        """0 inside the polygon, otherwise the distance to its nearest edge in pixels."""
        if self.contains(x, y):
            return 0.0
        a = self.polygon
        b = np.roll(a, -1, axis=0)
        ab = b - a
        t = np.clip(((x - a[:, 0]) * ab[:, 0] + (y - a[:, 1]) * ab[:, 1]) / ((ab ** 2).sum(axis=1) + 1e-12), 0, 1)
        nearest = a + t[:, None] * ab
        return float(np.min(np.hypot(nearest[:, 0] - x, nearest[:, 1] - y)))

    def bounds(self) -> Tuple[int, int, int, int]:
        x1, y1 = self.polygon.min(axis=0)
        x2, y2 = self.polygon.max(axis=0)
        return int(x1), int(y1), int(np.ceil(x2)), int(np.ceil(y2))


@dataclass
class CameraZones:
    camera_id: str
    resolution: Tuple[int, int]
    zones: List[Zone] = field(default_factory=list)

    def for_frame(self, width: int, height: int) -> "CameraZones":
        """Rescale to a stream of the same aspect ratio; refuse anything else."""
        w0, h0 = self.resolution
        if (width, height) == (w0, h0):
            return self
        if abs(width / height - w0 / h0) > 0.01:
            raise ValueError(
                f"Zones for camera '{self.camera_id}' were drawn at {w0}x{h0}, but the stream is "
                f"{width}x{height} with a different aspect ratio. Redraw the zones for this stream.")
        s = np.array([width / w0, height / h0])
        return CameraZones(self.camera_id, (width, height),
                           [Zone(z.name, z.polygon * s) for z in self.zones])

    def zone_of(self, foot_x: float, foot_y: float, margin_px: float = 0.0) -> Optional[str]:
        """Zone containing the foot point; with a margin, the nearest zone within that distance.

        The box bottom is a noisy foot estimate (box padding, occluded legs), so
        people standing at a zone edge need a tolerance band.
        """
        if not self.zones:
            return "frame"
        best, best_d = None, np.inf
        for z in self.zones:
            d = z.distance_outside(foot_x, foot_y)
            if d == 0.0:
                return z.name
            if d <= margin_px and d < best_d:
                best, best_d = z.name, d
        return best


def load_zones(path: Path, camera_id: str) -> Optional[CameraZones]:
    path = Path(path)
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    cam = data.get(camera_id)
    if cam is None:
        return None
    zones = [Zone(z["name"], np.asarray(z["polygon"], dtype=float)) for z in cam["zones"]]
    for z in zones:
        if len(z.polygon) < 3:
            raise ValueError(f"Zone '{z.name}' of camera '{camera_id}' needs >= 3 points")
    return CameraZones(camera_id, tuple(cam["resolution"]), zones)


def save_zones(path: Path, cam: CameraZones) -> None:
    path = Path(path)
    data: Dict = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    data[cam.camera_id] = {
        "resolution": list(cam.resolution),
        "zones": [{"name": z.name, "polygon": np.round(z.polygon).astype(int).tolist()} for z in cam.zones],
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
