"""Content of the Manual tab in labelling_studio.py (kept apart from the GUI code).

Block types: ("h1"|"h2"|"p"|"tip"|"warn", text), ("bullets", [text]),
("steps", [text]), ("table", header, rows), ("phases",), ("visibility",),
("keys", [(key, text)]), ("check", id, [text]) - an interactive checklist,
("button", label, action). Inline: **bold**, `code`.
"""

CHAPTERS = [
    ("1. Welcome - what you are making", [
        ("h1", "Welcome to the Labelling Studio"),
        ("p", "You will watch short store-camera videos and describe, over time, **what each person's hands do "
              "with merchandise** and **what the camera can see**. These labels train the Stage A shoplifting "
              "classifier, and they are also used to measure how many thefts it catches and how often it raises a "
              "false alarm."),
        ("p", "The whole job happens in this one program, in four tabs:"),
        ("table", ("Tab", "What you do there"), [
            ("Label", "Open a video, create persons from the tracker's boxes, paint phases and visibility on the timeline"),
            ("Check", "See every video's status: READY, IN PROGRESS, NOT READY or NOT STARTED, with the exact reason"),
            ("Export", "Pack the READY videos into one zip for the training pipeline"),
            ("Manual", "This guide, a phase decision helper, an error fixer and a practice quiz"),
        ]),
        ("tip", "A video the Check tab calls READY is exactly what the training pipeline accepts. When everything "
                "you send is READY, nobody needs to send it back to you."),
        ("h2", "Three rules that matter most"),
        ("steps", [
            "**Label what happens, not intent.** An item held at the hip is not a theft until it goes into a pocket, "
            "clothing or a bag.",
            "**Every person who appears gets labelled for their whole time on screen**, not only the thief.",
            "**actor_id names a real individual.** The same person keeps the same actor_id in every video; "
            "different people never share one.",
        ]),
    ]),
    ("2. Your first video, step by step", [
        ("h1", "Your first video, step by step"),
        ("p", "Tick each step as you go. Your ticks are remembered on this computer."),
        ("check", "first_video", [
            "Enter your name in **Reviewer** (top of the Label tab). It is saved into every label file.",
            "Pick a video from the list and press **Open**. The first time, decoding takes a few seconds.",
            "Press **Space** and watch the **whole video once** before labelling anything. Note who appears.",
            "Click a person's grey box and press **N** to create a person (p1, p2, ...).",
            "If the box disappears and comes back with a new number, select the person, click the new box, press **G**.",
            "Give the person an **actor_id** (Persons panel, or press **I**). Use the same id as in other videos for the same individual.",
            "Staff member? Tick **Staff** (or press **T**).",
            "Paint the interesting parts: **S** at the start, move to the end, press a phase key (1-7, 0).",
            "Paint visibility the same way with **V / O / B** wherever the hands or the body are hidden.",
            "For a theft: **E** starts a new event, **4** for the pick of the stolen item, **5** for the concealment.",
            "Press **F** to fill the rest of the person's time with normal + visible.",
            "Repeat for every person. The Issues panel shows what is still missing.",
            "Set the **Session** id (same id for every clip of one recording day, for example S1).",
            "Press **C** (Mark complete), go through the review checklist, confirm.",
            "Go to the **Check** tab: the video should now say READY.",
            "When you have new READY videos, go to **Export** and create the zip.",
        ]),
        ("button", "Open the Label tab", "goto_label"),
    ]),
    ("3. The Label tab, explained", [
        ("h1", "The Label tab, explained"),
        ("table", ("Area", "Meaning"), [
            ("Video", "Coloured boxes are your persons (name, phase, visibility, event). Grey boxes are tracker "
                      "tracks not yet linked to anyone. Click a box to select it."),
            ("Transport", "Play/pause and step buttons, the time slider and the current time."),
            ("Timeline", "Top rows: the selected person's span, phase and visibility. Then missed events, your "
                         "marked range (yellow) and one thin row per person. Click to jump; click a person row to select."),
            ("Action bar", "Range, phase, visibility and event buttons. Every button shows its keyboard key."),
            ("Persons", "All persons with actor id, staff flag, linked tracks and how much of their time is labelled."),
            ("Segments", "The selected person's segments: double-click to jump, re-select a range, or delete one."),
            ("Issues", "Live check of this video: READY or the blocking problems, and how to fix the selected one."),
        ]),
        ("tip", "Everything saves automatically after every change. **X** or **Ctrl+Z** undoes the last change "
                "(up to 100 steps)."),
        ("warn", "Keyboard shortcuts do nothing while you are typing in a text field. Press **Enter** or click the "
                 "video to give the keys back to the labelling."),
    ]),
    ("4. Persons, tracks and actor ids", [
        ("h1", "Persons, tracks and actor ids"),
        ("p", "The tracker gives each detected body a **track number** (#3). Trackers lose people and give them new "
              "numbers, so a **person** (p1) is one or more tracks that you have checked belong to one individual."),
        ("table", ("Action", "How"), [
            ("New person", "Click an unlinked grey box, press **N**"),
            ("Add a track to a person", "Select the person (click their box or the Persons list), click the new "
                                        "grey box, press **G**"),
            ("Remove a wrong track", "Click the box, press **U**"),
            ("Delete a person created by mistake", "Persons panel > Delete person"),
            ("actor_id", "Persons panel > Actor id > Set (or **I**). Format A1, A2, ..."),
            ("Staff", "Persons panel > Staff (or **T**)"),
        ]),
        ("h2", "actor_id - the field that is easiest to get wrong"),
        ("p", "The training pipeline keeps one individual out of both the training and the test data by joining "
              "videos that share an actor_id. So:"),
        ("bullets", [
            "Same individual (same face, same clothes) in two videos = **same actor_id** in both.",
            "Different individuals = **different actor_ids**, even in different videos.",
            "**Do not number actors by person order** (p1=A1, p2=A2 in every video). That says the first person "
            "of every video is the same human, which wrongly joins every video into one group.",
            "The actor box offers ids already used in other videos. Use **Check > Actor gallery** to see one crop per "
            "actor per video and confirm each row shows one individual.",
        ]),
        ("warn", "Watch track crossings: when two people pass each other the tracker may swap their numbers. Check "
                 "the boxes after each crossing and fix links with U and G."),
    ]),
    ("5. Phases - what the hands do", [
        ("h1", "Phases - what the hands do"),
        ("p", "Exactly one phase at any time for each person. Put the playhead at the start, press **S**, move to "
              "the end, press the key. Without S, a key labels only the current frame."),
        ("phases",),
        ("h2", "Rules"),
        ("bullets", [
            "Label what happens, not intent. Holding an item at the hip is inspect or normal until it actually goes "
            "into a pocket, bag or clothing.",
            "If a boundary is genuinely uncertain by more than about 0.5 s, label the uncertain part **unknown (0)** "
            "rather than guessing. You do not need to pad suspicious segments: the training build already excludes "
            "0.3 s at each edge.",
            "One suspicious segment per item movement. Two separate concealments are two segments: the same event "
            "if it is the same theft episode, a new event otherwise.",
            "A purchase pick (3) never has an event. The pick of an item that is later concealed is key **4**.",
        ]),
        ("button", "Try the phase decision helper", "goto_decision"),
    ]),
    ("6. Visibility - what the camera sees", [
        ("h1", "Visibility - what the camera sees"),
        ("p", "Also exactly one value at any time. It describes **this camera's view**, not what you inferred."),
        ("visibility",),
        ("p", "Example (159 Back Cooler_05): the shopper's hand is visible at the peg at about 6 s (pick, visible). "
              "From about 8 s his back hides both hands while he conceals (suspicious, hands_occluded)."),
        ("tip", "Hidden-hands concealment is still labelled **suspicious**. Training never asks the model to see "
                "through a body; these segments train the visibility head and are caught by the shelf-change check."),
    ]),
    ("7. Events and missed events", [
        ("h1", "Events and missed events"),
        ("p", "An **event** is one theft episode of one person: its suspicious segment(s) and the pick(s) of the "
              "concealed items, all carrying the same event id (ev1, ev2, ...)."),
        ("table", ("Key", "Action"), [
            ("E", "Start a new event; it becomes the current event"),
            ("W", "Cycle the current event through the existing ones"),
            ("4", "Pick of a stolen item - tagged with the current event"),
            ("5", "Suspicious (concealment) - tagged with the current event"),
            ("M", "Missed event: a concealment the detector missed entirely (no box)"),
        ]),
        ("bullets", [
            "Pressing 4 or 5 with no current event creates one automatically.",
            "Every suspicious segment must belong to an event; an event with a pick needs a suspicious segment "
            "(or a missed event).",
            "An event that spans two persons raises a warning (accomplices). That is fine if intended.",
            "**Missed event (M):** mark the range, press M and describe it. It counts against recall even though no "
            "person can carry it.",
        ]),
    ]),
    ("8. Complete, READY and the Check tab", [
        ("h1", "Complete, READY and the Check tab"),
        ("p", "**Mark complete (C)** means: every person who appears is labelled for their whole time on screen, "
              "every concealment is an event, and actor ids and staff flags are set. The studio runs the full "
              "checks first and refuses if anything blocks; then it asks you to confirm the review checklist."),
        ("table", ("Status", "Meaning"), [
            ("READY", "Complete and nothing blocks - the training pipeline will use it as it is"),
            ("IN PROGRESS", "Labels exist but the video is not marked complete yet"),
            ("NOT READY", "Marked complete but something blocks (for example a missing session id or registry entry)"),
            ("NOT STARTED", "Registered video with no labels yet"),
        ]),
        ("p", "Blocking problems are also listed live in the Label tab's **Issues** panel. Select one to see how to "
              "fix it, double-click it to jump to the person and time."),
        ("tip", "If you change a complete video so that it no longer passes the checks, it is set back to "
                "incomplete automatically. A complete flag therefore always means it passed the checks."),
        ("h2", "Session id"),
        ("p", "A session is one recording occasion: same day, same actors and staff. Clips cut from one recording "
              "share a session id (S1, S2, ...). The training build will not start without it, because it keeps a "
              "whole session on one side of the train/test split. Ask your project lead once for the session list "
              "if you do not know it."),
    ]),
    ("9. Exporting to the training pipeline", [
        ("h1", "Exporting to the training pipeline"),
        ("steps", [
            "Open the **Export** tab. Only READY videos can be ticked.",
            "**Select new/changed** ticks the videos that were never exported or changed since the last export.",
            "Press **Export zip**. The zip is written to the exports folder and checked again straight away.",
            "Send that one zip file to the training team. Do not send videos, review MP4s or loose JSON files.",
        ]),
        ("p", "Inside the zip: the label files, the registry entries of those videos (with session ids), the "
              "reference tracks and a manifest with a checksum for every file. On the training side one command "
              "verifies and imports it:"),
        ("code", "python -m shoplift.label_exchange import labels_<you>_<date>.zip"),
        ("p", "Import re-runs the same checks, backs up any label file it replaces, and never changes the training "
              "side's video paths, holdout flags or tracks."),
        ("warn", "Client footage is confidential. Never upload or share the videos themselves."),
    ]),
    ("10. Keyboard shortcuts", [
        ("h1", "Keyboard shortcuts"),
        ("p", "Same keys as the older annotate.py, so the tutorial recording still applies."),
        ("keys", [
            ("Space", "play / pause"), ("D / A or Right / Left", "next / previous frame (0.1 s)"),
            ("L / J", "+2 s / -2 s"), ("K / H", "+10 s / -10 s"), ("Home / End", "first / last frame"),
            ("S", "set range start at the playhead"), ("Esc", "clear the range"),
            ("1 2 3 4 5 6 7 0", "normal, inspect, pick, pick (event), suspicious (event), basket, return, unknown"),
            ("V / O / B", "visible, hands occluded, body occluded"),
            ("N", "new person from the selected track"), ("G", "link selected track to the selected person"),
            ("U", "unlink the selected track"), ("I", "edit actor id"), ("T", "toggle staff"),
            ("E / W", "new event / cycle current event"), ("M", "missed event over the range"),
            ("F", "fill the person's unlabelled time with normal + visible"),
            ("C", "mark complete"), ("X, Backspace or Ctrl+Z", "undo"),
            ("Z", "reset the selected person's labels (asks first)"), ("R", "reset all labels (asks first)"),
        ]),
    ]),
    ("11. Common mistakes", [
        ("h1", "Common mistakes (and how the studio catches them)"),
        ("table", ("Mistake", "What to do instead"), [
            ("Labelling only the thief", "Every person in the video gets a person and full-time labels (F helps)"),
            ("actor_id = person number", "actor_id names an individual across all videos; check the gallery"),
            ("Theft pick labelled with 3", "The pick of an item that is later concealed is 4 (same event)"),
            ("Suspicious while the item is only held", "Suspicious starts when the hand moves toward the "
                                                        "body/bag and ends when it comes away empty"),
            ("Visible during a back-turned concealment", "If you cannot see the hands, it is O (hands occluded)"),
            ("Staff not marked", "Tick Staff - staff restock and handle stock all day"),
            ("Editing JSON files by hand", "Never; use the studio. Hand edits break checksums and formats"),
            ("Sending loose files", "Send only the exported zip"),
        ]),
    ]),
]

# Phase table rows: (key, phase, definition, starts, ends)
PHASE_ROWS = [
    ("1", "normal", "No merchandise handling: walking, standing, browsing with the eyes, phone/ATM/counter", "-", "-"),
    ("2", "inspect", "Holding an item and looking at it", "item first held away from the shelf",
     "item put down / another phase starts"),
    ("3", "pick", "Taking an item from a shelf/cooler that is NOT later concealed (purchase)",
     "hand reaches into the shelf area", "item is out of the shelf area"),
    ("4", "pick + event", "Same, for an item that IS later concealed - links it to the theft event", "as above", "as above"),
    ("5", "suspicious", "Moving an item into clothing, a pocket, waistband or a personal bag (not a shop basket)",
     "the hand holding the item starts moving toward body/bag", "the hand comes away empty"),
    ("6", "basket", "Placing an item in a shop basket/cart or openly carrying it to pay", "hand moves toward basket",
     "hand leaves basket"),
    ("7", "return", "Putting an item back on a shelf", "hand moves toward shelf with item", "hand leaves shelf empty"),
    ("0", "unknown", "Cannot decide (too small, blurred, ambiguous by more than ~0.5 s)", "-", "-"),
]
VIS_ROWS = [
    ("V", "visible", "You can see the hands (or both hands' positions are unambiguous)"),
    ("O", "hands_occluded", "Body visible but hands hidden: back to camera with hands in front, hands behind a "
                            "shelf/cooler door, hands inside a bag"),
    ("B", "body_occluded", "Most of the body is hidden (behind a gondola or another person)"),
]

# ---------------------------------------------------------------- decision helper
# node: (question, yes, no) ; leaf: ("=", key, title, explanation)
PHASE_TREE = {
    "start": ("Is the person touching, holding or moving an item of merchandise right now? "
              "(Count it as yes if you can tell an item is being moved even though the hands are hidden.)",
              "conceal", "normal"),
    "conceal": ("Is the item going into clothing, a pocket, the waistband or a personal bag (not a shop basket)?",
                "susp", "shelf"),
    "shelf": ("Is a hand reaching into the shelf or cooler and taking the item out?", "later", "basket"),
    "later": ("Watch ahead: is this same item concealed later in the video?", "pick_ev", "pick"),
    "basket": ("Is the item being put into a shop basket or cart, or carried openly to pay?", "basket_l", "ret"),
    "ret": ("Is the item being put back onto a shelf?", "return", "insp"),
    "insp": ("Is the person holding the item and looking at it?", "inspect", "unknown"),
    "normal": ("=", "1", "normal", "No merchandise handling. Walking, standing, looking at shelves, using a phone "
                                   "or the ATM are all normal."),
    "susp": ("=", "5", "suspicious (with event)", "Start when the hand holding the item starts moving toward the "
             "body or bag; end when the hand comes away empty. Press E first if this is a new theft episode. "
             "If the hands are hidden during it, still label suspicious and set visibility O or B."),
    "pick_ev": ("=", "4", "pick of a stolen item (with event)", "Use the same event as the later concealment "
                "(W selects it). Start when the hand enters the shelf area, end when the item is out."),
    "pick": ("=", "3", "pick (purchase)", "No event. Start when the hand enters the shelf area, end when the item "
             "is out of it."),
    "basket_l": ("=", "6", "basket", "From the hand moving toward the basket until it leaves the basket."),
    "return": ("=", "7", "return", "From the hand moving toward the shelf with the item until it leaves empty."),
    "inspect": ("=", "2", "inspect", "Holding an item away from the shelf and looking at it."),
    "unknown": ("=", "0", "unknown", "You cannot decide. Use unknown for the uncertain part rather than guessing "
                "(only when the uncertainty is more than about 0.5 s)."),
}
VIS_TREE = {
    "start": ("Can you see the person's hands (or are both hands' positions unambiguous)?", "v", "body"),
    "body": ("Is most of the body hidden (behind a gondola, a cooler door or another person)?", "b", "o"),
    "v": ("=", "V", "visible", "The default. Most of the time people are visible."),
    "b": ("=", "B", "body_occluded", "Most of the body hidden."),
    "o": ("=", "O", "hands_occluded", "Body visible, hands hidden (back to camera, hands behind a door or "
                                       "inside a bag)."),
}

# ---------------------------------------------------------------- quiz
QUIZ = [
    ("A shopper walks down the aisle looking at the shelves without touching anything.",
     ["normal (1)", "inspect (2)", "unknown (0)"], 0,
     "Looking with the eyes is normal. inspect needs an item in the hand."),
    ("A shopper takes a soda from the cooler and later puts it in a shop basket. How do you label the reach into "
     "the cooler?", ["pick (3)", "pick with event (4)", "basket (6)"], 0,
     "The soda is never concealed, so it is a purchase pick with no event. The basket part is 6."),
    ("A man takes a chocolate bar from a shelf and five seconds later slips it into his jacket pocket. "
     "How do you label the moment he takes it from the shelf?",
     ["pick (3)", "pick with event (4)", "suspicious (5)"], 1,
     "The item is concealed later, so the pick is linked to the theft event with key 4."),
    ("Same man: where does the suspicious segment start and end?",
     ["From the pick until he leaves the store", "From when the hand with the bar starts moving toward the pocket "
      "until the hand comes away empty", "Only the frame where the bar disappears"], 1,
     "That is the definition of suspicious. The builder already trims 0.3 s at both edges; do not pad."),
    ("While concealing, the shopper's back is to the camera and you cannot see his hands. What do you label?",
     ["unknown + visible", "suspicious + hands_occluded", "normal + body_occluded"], 1,
     "Label what happens (suspicious) and what the camera sees (hands occluded)."),
    ("A shopper holds an item at hip height for a while but does not put it anywhere yet.",
     ["suspicious (5)", "inspect or normal", "unknown (0)"], 1,
     "Label what happens, not intent. It only becomes suspicious when it goes into a pocket, clothing or a bag."),
    ("A concealment clearly happens, but the detector lost the person: there is no box at all.",
     ["Skip it - no box, no label", "Mark the range and press M (missed event)", "Create a new person"], 1,
     "Missed events count against recall, so they must be recorded."),
    ("The same woman in a red coat appears in video 3 (as p2) and in video 7 (as p1). Which actor ids?",
     ["A2 in video 3 and A1 in video 7", "The same actor id in both videos", "No actor id needed"], 1,
     "actor_id names the individual, not the person number. Same individual = same actor id everywhere."),
    ("A store employee restocks shelves in the background.",
     ["Ignore staff", "Create a person, tick Staff, label phases normally", "Label them suspicious"], 1,
     "Every person is labelled; staff are marked with T so the model can learn they handle stock legitimately."),
    ("You press C and get: 'p2: phase not labelled for 3.0-5.2s'. What now?",
     ["Edit the JSON file", "Select p2 and label 3.0-5.2 s (or press F if it is normal + visible)",
      "Ignore it and export"], 1,
     "Unlabelled time inside a person's span blocks completion. F fills gaps with normal + visible."),
    ("When is a video ready to send to the training team?",
     ["When I have labelled the thief", "When the Check tab says READY", "After I save with C once"], 1,
     "READY means complete and no blocking problems - exactly what the training pipeline accepts."),
]

# ---------------------------------------------------------------- error fixer
# (regex, meaning, fix)
ISSUE_HELP = [
    (r"no box trajectory", "The person has no linked track left, so they have no boxes.",
     "Link a track to them with G, or delete the person in the Persons panel."),
    (r"track \d+ linked to both", "One tracker track belongs to two persons.",
     "Click the box, press U to unlink it from the wrong person."),
    (r"overlapping .* segments", "Two segments overlap (usually a hand-edited file).",
     "Delete one of them in the Segments panel and repaint the range."),
    (r"invalid (phase|visibility)", "A value from an old or hand-edited file.",
     "Repaint that range with a phase/visibility key."),
    (r"not labelled for", "Part of the person's time on screen has no phase or no visibility.",
     "Select the person, label the listed time ranges, or press F to fill them with normal + visible."),
    (r"involved in an event but has no actor_id", "A person in a theft event must have an actor id "
     "(needed for leakage-free train/test splits).", "Persons panel > Actor id > Set."),
    (r"no actor_id", "The person has no actor id.", "Persons panel > Actor id > Set (same id as in other videos "
                                                     "for the same individual)."),
    (r"has a pick but no conceal", "An event has a pick (key 4) but no suspicious segment and no missed event.",
     "Either label the concealment with the same event (W to select it, then 5) or relabel the pick with 3 if "
     "the item was bought."),
    (r"spans persons", "One event is used by several persons (accomplices).",
     "Fine if two people cooperate on one theft; otherwise give one of them a new event (E)."),
    (r"has no event", "A suspicious segment has no event id.", "Repaint it with key 5 (it takes the current event)."),
    (r"carries event", "Only pick and suspicious may carry an event.", "Repaint the range with its key."),
    (r"not in labels/videos\.json", "The video is not registered, so the training pipeline cannot find it.",
     "Check tab > select the video > Register video file, and choose the original video file."),
    (r"different video content", "The label file belongs to another version of the video.",
     "Make sure you opened the right file; ask the project lead."),
    (r"session_id", "The video has no session id.",
     "Type it in the Session box in the Label tab (or the Check tab) and press Enter."),
    (r"reviewer not set", "Your name is missing.", "Type it in the Reviewer box in the Label tab, press Enter."),
    (r"not marked complete", "You have not marked the video complete yet.",
     "When every person is fully labelled, press C (Mark complete)."),
    (r"reference tracks changed", "The tracker file is newer than these labels, so track numbers may differ.",
     "Open the video and press 'Re-link tracks' in the Persons panel; person boxes are kept."),
    (r"reference tracks CSV is not on this machine", "Labels are fine, but the tracker file is missing here.",
     "Nothing to do for READY; the export simply will not include tracks."),
    (r"pick\(s\) by a person who later conceals", "That person conceals something, and some of their picks "
     "have no event.", "If a picked item is the stolen one, relabel that pick with 4 (same event)."),
    (r"outside person span", "A segment extends beyond the person's time on screen (harmless).",
     "Optional: repaint so the range ends where the person's box ends."),
    (r"marked complete with no persons", "Nobody is labelled.", "Only correct if the video has no people."),
    (r"actor_id equals the person number", "actor ids look like p1=A1, p2=A2 in every video.",
     "Rename actor ids so each one is a real individual. Use Check > Actor gallery to compare crops."),
    (r"split group", "Too few independent groups for a 5-fold training split.",
     "Usually caused by wrong actor ids or missing session ids; fix those first."),
    (r"staff in .* but a shopper", "The same actor id is staff in one video and a shopper in another.",
     "Check whether that is really one individual; otherwise use different actor ids."),
    (r"both hold labels", "Two label files describe the same video.", "Delete or rename the older one."),
    (r"lock/temporary file", "A label file was opened in another program.", "Close it and delete the ~$ file."),
]


def issue_help(text: str):
    import re
    for pattern, meaning, fix in ISSUE_HELP:
        if re.search(pattern, text):
            return meaning, fix
    return None
